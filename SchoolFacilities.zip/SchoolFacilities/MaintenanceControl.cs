using System.Data;

namespace SchoolFacilities;

/// <summary>Quản lý bảo trì: đồng bộ tình trạng thiết bị theo trạng thái yêu cầu.</summary>
public class MaintenanceControl : CrudControl
{
    const string ListSqlText =
        @"SELECT m.MaintenanceId AS Id, e.AssetCode AS [Mã tài sản], e.Name AS [Thiết bị],
                 m.ReportDate AS [Ngày báo], m.Description AS [Mô tả sự cố], m.Status AS [Trạng thái],
                 m.CompletedDate AS [Ngày hoàn thành], m.Cost AS [Chi phí], u.FullName AS [Người báo]
          FROM Maintenance m
          JOIN Equipment e ON e.EquipmentId = m.EquipmentId
          LEFT JOIN Users u ON u.UserId = m.ReportedBy
          ORDER BY m.ReportDate DESC, m.MaintenanceId DESC";

    static readonly List<FieldDef> FieldList = new()
    {
        new() { Column = "EquipmentId", Label = "Thiết bị", Kind = FieldKind.Combo, Required = true, ComboSql = Sql.EquipmentCombo },
        new() { Column = "ReportDate", Label = "Ngày báo", Kind = FieldKind.Date, Required = true, Default = DateTime.Today },
        new() { Column = "Description", Label = "Mô tả sự cố", Kind = FieldKind.Multiline, Required = true },
        new() { Column = "Status", Label = "Trạng thái", Kind = FieldKind.Combo, Required = true, ComboItems = Lists.MaintenanceStatus },
        new() { Column = "CompletedDate", Label = "Ngày hoàn thành", Kind = FieldKind.Date, AllowNull = true },
        new() { Column = "Cost", Label = "Chi phí (đ)", Kind = FieldKind.Decimal },
    };

    public MaintenanceControl()
        : base("Quản lý bảo trì", "yêu cầu bảo trì", "Maintenance", "MaintenanceId", ListSqlText, FieldList, Session.IsAdmin)
    {
        // Nút dựng sẵn trong CrudControl.Designer (btnComplete): ở đây chỉ bật lên.
        BtnComplete.Visible = true;
        BtnComplete.Click += (_, _) => Complete();
    }

    protected override string? ValidateValues(Dictionary<string, object?> v, bool isNew)
    {
        if ((string?)v["Status"] == "Hoàn thành" && v["CompletedDate"] == null)
            return "Trạng thái \"Hoàn thành\" cần có ngày hoàn thành (tích vào ô bên cạnh ô ngày).";
        return null;
    }

    protected override Dictionary<string, object?> Transform(Dictionary<string, object?> v, bool isNew)
    {
        var copy = new Dictionary<string, object?>(v);
        if (isNew) copy["ReportedBy"] = Session.UserId;
        return copy;
    }

    protected override void AfterSave(int? id, DataRow? oldRow, Dictionary<string, object?> v, bool isNew)
    {
        var equipmentStatus = (string?)v["Status"] switch
        {
            "Hoàn thành" => "Tốt",
            "Đang xử lý" => "Đang bảo trì",
            _ => "Hỏng"
        };
        Db.Exec("UPDATE Equipment SET Status = @s WHERE EquipmentId = @e AND Status <> N'Đã thanh lý'",
                ("@s", equipmentStatus), ("@e", v["EquipmentId"]));
    }

    void Complete()
    {
        var id = RequireSelection();
        if (id == null) return;

        var fields = new List<FieldDef>
        {
            new() { Column = "CompletedDate", Label = "Ngày hoàn thành", Kind = FieldKind.Date, Required = true, Default = DateTime.Today },
            new() { Column = "Cost", Label = "Chi phí (đ)", Kind = FieldKind.Decimal },
        };
        using var dlg = new EditDialog("Hoàn thành bảo trì", fields);
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;

        try
        {
            Db.Exec(@"SET XACT_ABORT ON; BEGIN TRAN;
                      UPDATE Maintenance SET Status = N'Hoàn thành', CompletedDate = @d, Cost = @c WHERE MaintenanceId = @id;
                      UPDATE Equipment SET Status = N'Tốt'
                       WHERE EquipmentId = (SELECT EquipmentId FROM Maintenance WHERE MaintenanceId = @id)
                         AND Status <> N'Đã thanh lý';
                      COMMIT;",
                    ("@id", id.Value), ("@d", dlg.Values["CompletedDate"]), ("@c", dlg.Values["Cost"]));
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }
}
