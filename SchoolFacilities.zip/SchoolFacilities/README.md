# Quản lý cơ sở vật chất trường học (C# WinForms + SQL Server)

Ứng dụng tham khảo, giao diện lấy cảm hứng từ cổng thông tin sinh viên: thanh trên trắng, thẻ trắng bo góc có bóng, ô thống kê xanh/cam, hàng lối tắt và các biểu đồ.

## Yêu cầu
- Windows 10/11
- Visual Studio 2022 (khối lượng công việc ".NET desktop development") hoặc .NET 8 SDK
- SQL Server (bản Express hoặc LocalDB đều được) và SSMS (hoặc Azure Data Studio)

## Cài đặt
1. Mở `Database/schema.sql` trong SSMS rồi bấm Execute. Script tạo database `SchoolFacilities`, các bảng và dữ liệu mẫu.
   **Chạy lại script sẽ xóa toàn bộ dữ liệu cũ.**
2. Không cần sửa gì: ứng dụng tự dò SQL Server trên máy (`.\SQLEXPRESS`, LocalDB, `localhost`, tên máy...). Chỉ khi tự dò không được mới bỏ dấu `#` ở một dòng trong `connection.txt`.
3. Mở `SchoolFacilities.csproj` bằng Visual Studio, bấm F5. Hoặc chạy `dotnet run` trong thư mục dự án.

## Tài khoản mẫu
| Tên đăng nhập | Mật khẩu   | Vai trò | Quyền |
|---------------|------------|---------|-------|
| admin         | admin123   | Admin   | Toàn quyền, gồm xóa dữ liệu, quản lý người dùng, sửa thông tin trường |
| staff         | staff123   | Staff   | Thêm/sửa dữ liệu, không xóa, không vào trang Người dùng |

## Các trang
- **Trang chủ:** thông tin trường, số liệu tổng quan, yêu cầu bảo trì chưa xong, biểu đồ theo tình trạng và theo loại (lọc theo tòa nhà), danh sách bảo trì gần đây
- **Tòa nhà, Phòng, Loại thiết bị**
- **Thiết bị:** thêm/sửa/xóa, điều chuyển phòng (có lịch sử), báo hỏng
- **Bảo trì:** theo dõi yêu cầu, đánh dấu hoàn thành (tự cập nhật tình trạng thiết bị)
- **Báo cáo:** 5 báo cáo, xuất CSV mở bằng Excel
- **Người dùng** (chỉ Admin), đổi mật khẩu, đăng xuất

## Cấu trúc mã nguồn
| File | Nội dung |
|------|----------|
| `*.Designer.cs` | Toàn bộ giao diện (mở file `.cs` tương ứng ở chế độ Design để kéo thả) |
| `LoginForm`, `MainForm`, `EditDialog` | Các form: đăng nhập, khung chính (thanh trên + menu), hộp thoại thêm/sửa |
| `DashboardControl`, `ReportsControl`, `CrudControl` | Trang chủ, báo cáo, trang danh sách dùng chung |
| `EquipmentControl`, `MaintenanceControl`, `UsersControl` | Trang kế thừa `CrudControl` (chỉ thêm logic, bật các nút dựng sẵn) |
| `Pages.cs` | Khai báo dữ liệu các trang: bảng, truy vấn, danh sách trường (`FieldDef`) |
| `Controls.cs` | Control tự vẽ (ô thống kê, biểu đồ, thanh trên...). Sau khi Build sẽ hiện trong Toolbox |
| `Theme.cs`, `Core.cs`, `Program.cs` | Màu/font/biểu tượng GDI+, truy cập SQL Server, điểm khởi chạy (không có giao diện) |

## Lưu ý
- Mật khẩu băm SHA-256 không muối để đơn giản. Dự án thật nên dùng PBKDF2, bcrypt hoặc Argon2.
- Logo và ảnh đại diện được vẽ bằng mã. Muốn dùng logo trường, thay phần vẽ trong `LogoControl` (Controls.cs).

## Dùng Designer (kéo thả)
Sau khi **Build** (Ctrl+Shift+B), mở file `.cs` của `LoginForm`, `MainForm`, `EditDialog`, `DashboardControl`, `ReportsControl` hoặc `CrudControl` ở chế độ Design.
- **Trang chủ:** 7 ô lối tắt (`tileBuildings`...`tileLast`), 5 dòng bảo trì (`row1`...`row5`) và tiêu đề đều là control thật trong Designer; code chỉ đổ dữ liệu và ẩn/hiện.
- **MainForm:** các mục menu tài khoản / menu chức năng là `ToolStripMenuItem` trong `menuUser`, `menuModule` (khóa trang nằm ở thuộc tính `Tag`).
- **CrudControl:** lưới (kiểu dáng, màu), thanh công cụ, các nút `btnTransfer`, `btnBroken`, `btnComplete` (ẩn mặc định, trang Thiết bị/Bảo trì bật lên). Sửa ở đây là áp dụng cho mọi trang danh sách.
- **ReportsControl:** danh sách tên báo cáo nằm trong `cboReport.Items`; thứ tự phải khớp mảng `Reports` trong code.
- **EditDialog:** khung (tiêu đề, nút Lưu/Hủy, bảng `tlFields`) trong Designer; các dòng nhãn + ô nhập vẫn được sinh theo `FieldDef` vì một hộp thoại dùng chung cho nhiều trang.
- Các lớp `EquipmentControl`, `MaintenanceControl`, `UsersControl` kế thừa `CrudControl`: đừng sửa bố cục ở đó, hãy sửa ở `CrudControl`.
- `MainForm.LayoutTop()` vẫn căn thanh trên bằng code vì chiều rộng các liên kết phụ thuộc độ dài chữ.

