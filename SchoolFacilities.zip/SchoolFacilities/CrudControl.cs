using System.Data;
using System.Text;
using Microsoft.Data.SqlClient;
using static SchoolFacilities.Theme;

namespace SchoolFacilities;

/// <summary>
/// Trang quản lý dùng chung: lưới dữ liệu + tìm kiếm + Thêm / Sửa / Xóa.
/// Cột đầu tiên của ListSql phải đặt bí danh là Id (khóa chính, được ẩn đi).
/// </summary>
public partial class CrudControl : UserControl
{
    protected string Table = "";
    protected string KeyColumn = "";
    protected string ListSql = "";
    protected string EntityName = "";
    protected List<FieldDef> Fields = new();

    /// <summary>Truy cập lưới dữ liệu (đặt trong Designer với tên "grid").</summary>
    protected DataGridView Grid => grid;

    DataTable? _data;

    /// <summary>Constructor không tham số: dành cho Designer (và để lớp con có thể kế thừa).</summary>
    public CrudControl()
    {
        InitializeComponent();
    }

    public CrudControl(string title, string entityName, string table, string keyColumn,
                       string listSql, List<FieldDef> fields, bool allowDelete) : this()
    {
        EntityName = entityName;
        Table = table;
        KeyColumn = keyColumn;
        ListSql = listSql;
        Fields = fields;

        lblTitle.Text = title;
        btnDelete.Visible = allowDelete;
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        if (DesignMode) return;
        LoadData();
    }

    // ---------- Sự kiện của Designer ----------
    void btnAdd_Click(object? sender, EventArgs e) => AddItem();
    void btnEdit_Click(object? sender, EventArgs e) => EditItem();
    void btnDelete_Click(object? sender, EventArgs e) => DeleteItem();
    void btnRefresh_Click(object? sender, EventArgs e) => LoadData();
    void grid_CellDoubleClick(object? sender, DataGridViewCellEventArgs e) { if (e.RowIndex >= 0) EditItem(); }
    void grid_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e) => UiHelper.FormatStatusCell(grid, e);
    void txtSearch_TextChanged(object? sender, EventArgs e) => ApplyFilter();

    // ---------- Móc mở rộng cho lớp con ----------
    protected virtual string? ValidateValues(Dictionary<string, object?> v, bool isNew) => null;
    protected virtual Dictionary<string, object?> Transform(Dictionary<string, object?> v, bool isNew) => v;
    protected virtual void AfterSave(int? id, DataRow? oldRow, Dictionary<string, object?> v, bool isNew) { }
    protected virtual string? CanDelete(int id) => null;

    // ---------- Nút mở rộng (dựng sẵn trong Designer, ẩn mặc định; lớp con bật lên) ----------
    protected Button BtnTransfer => btnTransfer;
    protected Button BtnBroken => btnBroken;
    protected Button BtnComplete => btnComplete;

    public void SetSearch(string text) => txtSearch.Text = text;

    protected int? SelectedId
    {
        get
        {
            var row = Grid.CurrentRow;
            if (row == null || !Grid.Columns.Contains("Id")) return null;
            return row.Cells["Id"].Value is int i ? i : null;
        }
    }

    protected int? RequireSelection()
    {
        var id = SelectedId;
        if (id == null)
            MessageBox.Show(FindForm(), "Vui lòng chọn một dòng trong danh sách.", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        return id;
    }

    // ---------- Dữ liệu ----------
    public void LoadData()
    {
        try
        {
            _data = Db.Query(ListSql);
        }
        catch (Exception ex)
        {
            ShowError(ex);
            return;
        }

        Grid.DataSource = _data;
        if (Grid.Columns.Contains("Id")) Grid.Columns["Id"].Visible = false;
        UiHelper.FormatColumns(Grid);
        ApplyFilter();
    }

    void ApplyFilter()
    {
        if (_data == null) return;
        var text = txtSearch.Text.Trim();
        if (text.Length == 0)
        {
            _data.DefaultView.RowFilter = "";
            return;
        }

        var esc = new StringBuilder();
        foreach (var ch in text)
        {
            if (ch is '[' or ']' or '%' or '*') esc.Append('[').Append(ch).Append(']');
            else if (ch == '\'') esc.Append("''");
            else esc.Append(ch);
        }

        var parts = _data.Columns.Cast<DataColumn>()
            .Where(c => c.ColumnName != "Id")
            .Select(c => $"Convert([{c.ColumnName}], 'System.String') LIKE '%{esc}%'");
        try { _data.DefaultView.RowFilter = string.Join(" OR ", parts); }
        catch (DataException) { _data.DefaultView.RowFilter = ""; }
    }

    // ---------- Thêm / Sửa / Xóa ----------
    void AddItem()
    {
        using var dlg = new EditDialog($"Thêm {EntityName}", Fields) { Verify = v => ValidateValues(v, true) };
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;

        try
        {
            var values = Transform(dlg.Values, true);
            var cols = values.Keys.ToList();
            var sql = $"INSERT INTO {Table} ({string.Join(", ", cols)}) " +
                      $"VALUES ({string.Join(", ", cols.Select(c => "@" + c))})";
            Db.Exec(sql, values.Select(kv => ("@" + kv.Key, kv.Value)).ToArray());
            AfterSave(null, null, dlg.Values, true);
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    void EditItem()
    {
        var id = RequireSelection();
        if (id == null) return;

        DataRow old;
        try
        {
            var dt = Db.Query($"SELECT * FROM {Table} WHERE {KeyColumn}=@id", ("@id", id.Value));
            if (dt.Rows.Count == 0) { LoadData(); return; }
            old = dt.Rows[0];
        }
        catch (Exception ex)
        {
            ShowError(ex);
            return;
        }

        using var dlg = new EditDialog($"Sửa {EntityName}", Fields, old) { Verify = v => ValidateValues(v, false) };
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;

        try
        {
            var values = Transform(dlg.Values, false);
            if (values.Count > 0)
            {
                var set = string.Join(", ", values.Keys.Select(c => $"{c}=@{c}"));
                var args = values.Select(kv => ("@" + kv.Key, kv.Value)).Append(("@__id", (object?)id.Value)).ToArray();
                Db.Exec($"UPDATE {Table} SET {set} WHERE {KeyColumn}=@__id", args);
            }
            AfterSave(id, old, dlg.Values, false);
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    void DeleteItem()
    {
        var id = RequireSelection();
        if (id == null) return;

        var blocked = CanDelete(id.Value);
        if (blocked != null)
        {
            MessageBox.Show(FindForm(), blocked, "Không thể xóa", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var ask = MessageBox.Show(FindForm(), $"Bạn có chắc muốn xóa {EntityName} đang chọn?", "Xác nhận xóa",
                                  MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (ask != DialogResult.Yes) return;

        try
        {
            Db.Exec($"DELETE FROM {Table} WHERE {KeyColumn}=@id", ("@id", id.Value));
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    protected void ShowError(Exception ex)
    {
        string msg = ex is SqlException s
            ? s.Number switch
            {
                2627 or 2601 => "Dữ liệu bị trùng (mã hoặc tên đã tồn tại).",
                547 => "Không thể thực hiện vì dữ liệu đang được sử dụng ở nơi khác hoặc giá trị không hợp lệ.",
                _ => s.Message
            }
            : ex.Message;
        MessageBox.Show(FindForm(), msg, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
