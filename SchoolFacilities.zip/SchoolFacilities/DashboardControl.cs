using System.Data;
using static SchoolFacilities.Theme;

namespace SchoolFacilities;

/// <summary>Trang chủ kiểu cổng thông tin: thẻ thông tin, nhắc nhở, ô thống kê, lối tắt và biểu đồ.</summary>
public partial class DashboardControl : UserControl
{
    INavigator? _nav;
    bool _loading;
    ListRow[] _rows = Array.Empty<ListRow>();

    /// <summary>Constructor không tham số: dành cho Designer.</summary>
    public DashboardControl()
    {
        InitializeComponent();
        _rows = new[] { row1, row2, row3, row4, row5 };
    }

    public DashboardControl(INavigator nav) : this()
    {
        _nav = nav;
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        if (DesignMode) return;

        lnkInfoEdit.Visible = Session.IsAdmin;

        // Ô cuối của hàng lối tắt: Admin thấy "Người dùng", Staff thấy "Đổi mật khẩu".
        if (!Session.IsAdmin)
        {
            tileLast.Kind = IconKind.Key;
            tileLast.Caption = "Đổi mật khẩu";
        }

        Reload();
    }

    // ================= Sự kiện của Designer =================

    void lnkInfoEdit_Click(object? sender, EventArgs e) => _nav?.EditSchoolInfo();
    void lnkInfoMore_Click(object? sender, EventArgs e) => _nav?.Open("buildings");
    void lnkRemindMore_Click(object? sender, EventArgs e) => _nav?.Open("maintenance");
    void tileTotal_Click(object? sender, EventArgs e) => _nav?.Open("equipment");
    void tileAttention_Click(object? sender, EventArgs e) => _nav?.Open("maintenance");
    void row_Click(object? sender, EventArgs e) => _nav?.Open("maintenance");

    // Các ô lối tắt lưu khóa trang trong Tag (đặt ở Designer).
    void tileModule_Click(object? sender, EventArgs e)
    {
        if (sender is Control { Tag: string key }) _nav?.Open(key);
    }

    void tileLast_Click(object? sender, EventArgs e)
    {
        if (Session.IsAdmin) _nav?.Open("users");
        else _nav?.ChangePassword();
    }

    void cboBuilding_SelectedIndexChanged(object? sender, EventArgs e)
    {
        if (!_loading) LoadBars();
    }

    // ================= Nạp dữ liệu =================

    void Reload()
    {
        try
        {
            _loading = true;
            LoadInfo();
            LoadBuildingFilter();
            LoadDonut();
            LoadBars();
            LoadList();
        }
        catch (Exception ex)
        {
            MessageBox.Show(FindForm(), "Không tải được dữ liệu trang chủ:\n" + ex.Message, "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _loading = false;
        }
    }

    void LoadInfo()
    {
        var school = SchoolInfo.Load();
        var r = Db.Query(@"SELECT
                (SELECT COUNT(*) FROM Buildings)                                              AS Buildings,
                (SELECT COUNT(*) FROM Rooms)                                                  AS Rooms,
                (SELECT COUNT(*) FROM Equipment WHERE Status <> N'Đã thanh lý')               AS Total,
                (SELECT COUNT(*) FROM Equipment WHERE Status IN (N'Hỏng', N'Đang bảo trì'))   AS Attention,
                (SELECT COUNT(*) FROM Maintenance WHERE Status <> N'Hoàn thành')              AS Pending,
                (SELECT ISNULL(SUM(Price), 0) FROM Equipment WHERE Status <> N'Đã thanh lý')  AS Value").Rows[0];

        infoLeft.Items = new List<(string, string)>
        {
            ("Tên trường", school["SchoolName"]),
            ("Địa chỉ", school["Address"]),
            ("Năm học", school["SchoolYear"]),
            ("Hiệu trưởng", school["Principal"]),
        };
        infoRight.Items = new List<(string, string)>
        {
            ("Số tòa nhà", Convert.ToInt32(r["Buildings"]).ToString("N0")),
            ("Số phòng", Convert.ToInt32(r["Rooms"]).ToString("N0")),
            ("Số thiết bị", Convert.ToInt32(r["Total"]).ToString("N0")),
            ("Tổng giá trị", Convert.ToDecimal(r["Value"]).ToString("N0") + " đ"),
        };
        infoLeft.Invalidate();
        infoRight.Invalidate();

        tileTotal.Value = Convert.ToInt32(r["Total"]).ToString("N0");
        tileAttention.Value = Convert.ToInt32(r["Attention"]).ToString("N0");
        tileTotal.Invalidate();
        tileAttention.Invalidate();

        lblRemindNumber.Text = Convert.ToInt32(r["Pending"]).ToString();

        var recent = Db.Query(@"SELECT TOP 3 e.Name + N' – ' + m.Description AS Txt
                                FROM Maintenance m JOIN Equipment e ON e.EquipmentId = m.EquipmentId
                                WHERE m.Status <> N'Hoàn thành'
                                ORDER BY m.ReportDate DESC, m.MaintenanceId DESC");
        lblRemindText.Text = recent.Rows.Count == 0
            ? "Không có yêu cầu bảo trì nào đang chờ xử lý."
            : string.Join("  •  ", recent.Rows.Cast<DataRow>().Select(x => (string)x["Txt"]));
    }

    void LoadBuildingFilter()
    {
        var dt = Db.Query("SELECT BuildingId AS Id, Name AS Name FROM Buildings ORDER BY Name");
        var all = dt.NewRow();
        all["Id"] = DBNull.Value;
        all["Name"] = "Tất cả tòa nhà";
        dt.Rows.InsertAt(all, 0);
        cboBuilding.DataSource = dt;
        cboBuilding.DisplayMember = "Name";
        cboBuilding.ValueMember = "Id";
        if (cboBuilding.Items.Count > 0) cboBuilding.SelectedIndex = 0;
    }

    void LoadDonut()
    {
        var counts = Db.Query("SELECT Status, COUNT(*) AS N FROM Equipment GROUP BY Status").Rows
            .Cast<DataRow>().ToDictionary(r => (string)r["Status"], r => Convert.ToDouble(r["N"]));

        double Get(string k) => counts.TryGetValue(k, out var v) ? v : 0;

        donut.Data = new List<(string, double, Color)>
        {
            ("Tốt", Get("Tốt"), Ok),
            ("Đang bảo trì", Get("Đang bảo trì"), Warn),
            ("Hỏng", Get("Hỏng"), Danger),
            ("Đã thanh lý", Get("Đã thanh lý"), Gray),
        };
        donut.Invalidate();
    }

    void LoadBars()
    {
        object? buildingId = cboBuilding.SelectedValue is DBNull ? null : cboBuilding.SelectedValue;
        var dt = Db.Query(@"SELECT t.Name AS Name, COUNT(e.EquipmentId) AS N
                            FROM EquipmentTypes t
                            LEFT JOIN Equipment e ON e.TypeId = t.TypeId AND e.Status <> N'Đã thanh lý'
                                 AND (CAST(@b AS INT) IS NULL OR e.RoomId IN (SELECT RoomId FROM Rooms WHERE BuildingId = CAST(@b AS INT)))
                            GROUP BY t.Name
                            ORDER BY COUNT(e.EquipmentId) DESC, t.Name",
                          ("@b", buildingId));
        bars.Data = dt.Rows.Cast<DataRow>()
            .Take(8)
            .Select(r => ((string)r["Name"], Convert.ToDouble(r["N"])))
            .ToList();
        bars.Invalidate();
    }

    void LoadList()
    {
        var dt = Db.Query(@"SELECT TOP 5 e.AssetCode AS Code, e.Name AS Title, m.Status AS Status
                            FROM Maintenance m JOIN Equipment e ON e.EquipmentId = m.EquipmentId
                            WHERE m.Status <> N'Hoàn thành'
                            ORDER BY m.ReportDate DESC, m.MaintenanceId DESC");

        // Các dòng (row1..row5), dòng tiêu đề và nhãn "trống" đã dựng sẵn trong Designer: chỉ đổ dữ liệu / ẩn hiện.
        bool any = dt.Rows.Count > 0;
        rowHeader.Visible = any;
        lblListEmpty.Visible = !any;

        for (int i = 0; i < _rows.Length; i++)
        {
            if (i < dt.Rows.Count)
            {
                var r = dt.Rows[i];
                _rows[i].Code = (string)r["Code"];
                _rows[i].Title = (string)r["Title"];
                _rows[i].Status = (string)r["Status"];
                _rows[i].Visible = true;
            }
            else
            {
                _rows[i].Visible = false;
            }
        }
    }
}
