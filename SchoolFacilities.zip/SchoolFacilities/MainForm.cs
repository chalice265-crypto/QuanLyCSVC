using System.Data;
using System.Globalization;
using System.Text;
using static SchoolFacilities.Theme;

namespace SchoolFacilities;

/// <summary>Khung chính: thanh trên cùng (logo, tìm kiếm, trang chủ, thông báo, tài khoản) + vùng nội dung.</summary>
public partial class MainForm : Form, INavigator
{
    public bool LoggedOut { get; private set; }

    public MainForm()
    {
        InitializeComponent();
        // Menu đã dựng sẵn trong Designer; chỉ ẩn các mục dành riêng cho Admin.
        miEditSchool.Visible = Session.IsAdmin;
        miUsers.Visible = Session.IsAdmin;
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        if (DesignMode) return;

        // Đặt ở đây (sau khi Designer co giãn theo DPI) vì NavLink/UserChip tự tính chiều rộng theo chữ.
        logo.SchoolName = SchoolInfo.Load()["SchoolName"];
        chipUser.FullName = Session.FullName;
        lnkHome.Caption = "Trang chủ";
        lnkBell.Caption = "Thông báo";
        LayoutTop();
        ShowHome();
    }

    // ================= Sự kiện của Designer =================

    void btnMenu_Click(object? sender, EventArgs e) => menuModule.Show(btnMenu, new Point(0, btnMenu.Height));
    void lnkHome_Click(object? sender, EventArgs e) => ShowHome();
    void lnkBell_Click(object? sender, EventArgs e) => Open("maintenance");
    void chipUser_Click(object? sender, EventArgs e) => menuUser.Show(chipUser, new Point(0, chipUser.Height));
    void txtSearch_EnterPressed(object? sender, EventArgs e) => RunSearch(txtSearch.Text);
    void pnlTop_Resize(object? sender, EventArgs e) => LayoutTop();

    void pnlTop_Paint(object? sender, PaintEventArgs e)
    {
        using var pen = new Pen(Line);
        e.Graphics.DrawLine(pen, 0, pnlTop.Height - 1, pnlTop.Width, pnlTop.Height - 1);
    }

    // ================= Bố cục thanh trên =================

    void LayoutTop()
    {
        int w = pnlTop.ClientSize.Width;
        int h = pnlTop.Height;

        btnMenu.SetBounds(S(14), (h - S(40)) / 2, S(40), S(40));
        logo.SetBounds(S(66), (h - S(48)) / 2, S(330), S(48));

        int x = w - S(18);
        chipUser.Location = new Point(x - chipUser.Width, (h - chipUser.Height) / 2);
        x = chipUser.Left - S(6);
        lnkBell.Location = new Point(x - lnkBell.Width, (h - lnkBell.Height) / 2);
        x = lnkBell.Left;
        lnkHome.Location = new Point(x - lnkHome.Width, (h - lnkHome.Height) / 2);

        int left = logo.Right + S(24);
        int right = lnkHome.Left - S(24);
        int sw = Math.Max(S(160), Math.Min(S(440), right - left));
        txtSearch.SetBounds(left, (h - S(40)) / 2, sw, S(40));
    }

    // ================= Menu (các mục nằm trong MainForm.Designer.cs) =================

    void miChangePassword_Click(object? sender, EventArgs e) => ChangePassword();
    void miEditSchool_Click(object? sender, EventArgs e) => EditSchoolInfo();

    void miLogout_Click(object? sender, EventArgs e)
    {
        LoggedOut = true;
        Close();
    }

    void miHome_Click(object? sender, EventArgs e) => ShowHome();

    // Mỗi mục chức năng lưu khóa trang trong Tag (đặt ở Designer).
    void miModule_Click(object? sender, EventArgs e)
    {
        if (sender is ToolStripItem { Tag: string key }) Open(key);
    }

    // ================= Điều hướng =================

    public void Open(string key, string? search = null)
    {
        var module = AppModules.All.FirstOrDefault(x => x.Key == key);
        if (module == null || (module.AdminOnly && !Session.IsAdmin)) return;

        var page = module.Create();
        if (page is CrudControl crud && !string.IsNullOrEmpty(search)) crud.SetSearch(search);
        SetPage(page);
    }

    public void ShowHome() => SetPage(new DashboardControl(this));

    void SetPage(Control page)
    {
        pnlBody.SuspendLayout();
        foreach (var old in pnlBody.Controls.Cast<Control>().ToList())
        {
            pnlBody.Controls.Remove(old);
            // Giải phóng sau khi sự kiện Click hiện tại kết thúc (control cũ có thể là nơi phát sinh click).
            BeginInvoke(new Action(old.Dispose));
        }
        page.Dock = DockStyle.Fill;
        pnlBody.Controls.Add(page);
        pnlBody.ResumeLayout(true);
        RefreshBadge();
    }

    void RefreshBadge()
    {
        try
        {
            lnkBell.Badge = Convert.ToInt32(
                Db.Scalar("SELECT COUNT(*) FROM Maintenance WHERE Status <> N'Hoàn thành'") ?? 0);
        }
        catch
        {
            lnkBell.Badge = 0;
        }
    }

    /// <summary>Gõ tên chức năng để mở trang đó; nếu không khớp thì tìm trong danh sách thiết bị.</summary>
    void RunSearch(string text)
    {
        text = text.Trim();
        if (text.Length == 0) return;

        var q = Fold(text);
        var module = AppModules.All.FirstOrDefault(m => (!m.AdminOnly || Session.IsAdmin) && Fold(m.Title).Contains(q));
        if (module != null)
        {
            Open(module.Key);
            return;
        }
        Open("equipment", text);
    }

    static string Fold(string s)
    {
        var sb = new StringBuilder();
        foreach (var ch in s.Normalize(NormalizationForm.FormD))
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(ch == 'đ' ? 'd' : ch == 'Đ' ? 'D' : ch);
        }
        return sb.ToString().ToLowerInvariant();
    }

    // ================= Tài khoản / thông tin trường =================

    public void ChangePassword()
    {
        var fields = new List<FieldDef>
        {
            new() { Column = "Old", Label = "Mật khẩu hiện tại", Kind = FieldKind.Password, Required = true },
            new() { Column = "New", Label = "Mật khẩu mới", Kind = FieldKind.Password, Required = true },
            new() { Column = "Confirm", Label = "Nhập lại mật khẩu mới", Kind = FieldKind.Password, Required = true },
        };

        using var dlg = new EditDialog("Đổi mật khẩu", fields);
        dlg.Verify = v =>
        {
            var current = Convert.ToString(Db.Scalar("SELECT PasswordHash FROM Users WHERE UserId = @u", ("@u", Session.UserId)));
            if (!string.Equals(current, Security.Hash((string)v["Old"]!), StringComparison.OrdinalIgnoreCase))
                return "Mật khẩu hiện tại không đúng.";
            if (((string)v["New"]!).Length < 6)
                return "Mật khẩu mới phải có ít nhất 6 ký tự.";
            if ((string)v["New"]! != (string)v["Confirm"]!)
                return "Mật khẩu nhập lại không khớp.";
            return null;
        };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            Db.Exec("UPDATE Users SET PasswordHash = @h WHERE UserId = @u",
                    ("@h", Security.Hash((string)dlg.Values["New"]!)), ("@u", Session.UserId));
            MessageBox.Show(this, "Đã đổi mật khẩu.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    public void EditSchoolInfo()
    {
        if (!Session.IsAdmin) return;

        var info = SchoolInfo.Load();
        var table = new DataTable();
        foreach (var k in SchoolInfo.Keys) table.Columns.Add(k, typeof(string));
        var row = table.NewRow();
        foreach (var k in SchoolInfo.Keys) row[k] = info[k];
        table.Rows.Add(row);

        var fields = new List<FieldDef>
        {
            new() { Column = "SchoolName", Label = "Tên trường", Required = true },
            new() { Column = "Address", Label = "Địa chỉ" },
            new() { Column = "SchoolYear", Label = "Năm học" },
            new() { Column = "Principal", Label = "Hiệu trưởng" },
        };

        using var dlg = new EditDialog("Thông tin trường", fields, row);
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            SchoolInfo.Save(dlg.Values);
            logo.SchoolName = (string)dlg.Values["SchoolName"]!;
            ShowHome();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
