#nullable disable
namespace SchoolFacilities;

partial class LoginForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        card = new CardPanel();
        logo = new IconCircle();
        lblTitle = new Label();
        lblSub = new Label();
        lblUser = new Label();
        txtUser = new PillTextBox();
        lblPass = new Label();
        txtPass = new PillTextBox();
        btnLogin = new Button();
        lblExit = new Label();
        lblHint = new Label();
        card.SuspendLayout();
        SuspendLayout();
        // 
        // card
        // 
        card.Controls.Add(logo);
        card.Controls.Add(lblTitle);
        card.Controls.Add(lblSub);
        card.Controls.Add(lblUser);
        card.Controls.Add(txtUser);
        card.Controls.Add(lblPass);
        card.Controls.Add(txtPass);
        card.Controls.Add(btnLogin);
        card.Controls.Add(lblExit);
        card.Controls.Add(lblHint);
        card.Location = new Point(20, 20);
        card.Name = "card";
        card.Size = new Size(440, 570);
        card.TabIndex = 0;
        // 
        // logo
        // 
        logo.Fill = Color.FromArgb(24, 160, 245);
        logo.IconColor = Color.White;
        logo.Kind = IconKind.Building;
        logo.Location = new Point(176, 40);
        logo.Name = "logo";
        logo.Size = new Size(88, 88);
        logo.TabIndex = 0;
        // 
        // lblTitle
        // 
        lblTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
        lblTitle.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitle.Location = new Point(0, 142);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(440, 34);
        lblTitle.TabIndex = 1;
        lblTitle.Text = "QUẢN LÝ CƠ SỞ VẬT CHẤT";
        lblTitle.TextAlign = ContentAlignment.MiddleCenter;
        // 
        // lblSub
        // 
        lblSub.ForeColor = Color.FromArgb(120, 130, 145);
        lblSub.Location = new Point(0, 176);
        lblSub.Name = "lblSub";
        lblSub.Size = new Size(440, 26);
        lblSub.TabIndex = 2;
        lblSub.Text = "Đăng nhập để tiếp tục";
        lblSub.TextAlign = ContentAlignment.MiddleCenter;
        // 
        // lblUser
        // 
        lblUser.ForeColor = Color.FromArgb(55, 65, 81);
        lblUser.Location = new Point(50, 226);
        lblUser.Name = "lblUser";
        lblUser.Size = new Size(340, 24);
        lblUser.TabIndex = 3;
        lblUser.Text = "Tên đăng nhập";
        // 
        // txtUser
        // 
        txtUser.LeftIcon = IconKind.Users;
        txtUser.Location = new Point(50, 252);
        txtUser.Name = "txtUser";
        txtUser.PlaceholderText = "Nhập tên đăng nhập";
        txtUser.Size = new Size(340, 44);
        txtUser.TabIndex = 0;
        txtUser.EnterPressed += txtUser_EnterPressed;
        // 
        // lblPass
        // 
        lblPass.ForeColor = Color.FromArgb(55, 65, 81);
        lblPass.Location = new Point(50, 312);
        lblPass.Name = "lblPass";
        lblPass.Size = new Size(340, 24);
        lblPass.TabIndex = 5;
        lblPass.Text = "Mật khẩu";
        // 
        // txtPass
        // 
        txtPass.LeftIcon = IconKind.Key;
        txtPass.Location = new Point(50, 338);
        txtPass.Name = "txtPass";
        txtPass.Password = true;
        txtPass.PlaceholderText = "Nhập mật khẩu";
        txtPass.Size = new Size(340, 44);
        txtPass.TabIndex = 1;
        txtPass.EnterPressed += txtPass_EnterPressed;
        // 
        // btnLogin
        // 
        btnLogin.BackColor = Color.FromArgb(24, 160, 245);
        btnLogin.Cursor = Cursors.Hand;
        btnLogin.FlatAppearance.BorderSize = 0;
        btnLogin.FlatAppearance.MouseOverBackColor = Color.FromArgb(59, 176, 246);
        btnLogin.FlatStyle = FlatStyle.Flat;
        btnLogin.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
        btnLogin.ForeColor = Color.White;
        btnLogin.Location = new Point(50, 414);
        btnLogin.Name = "btnLogin";
        btnLogin.Size = new Size(340, 46);
        btnLogin.TabIndex = 2;
        btnLogin.Text = "ĐĂNG NHẬP";
        btnLogin.UseVisualStyleBackColor = false;
        btnLogin.Click += btnLogin_Click;
        // 
        // lblExit
        // 
        lblExit.Cursor = Cursors.Hand;
        lblExit.ForeColor = Color.FromArgb(120, 130, 145);
        lblExit.Location = new Point(0, 472);
        lblExit.Name = "lblExit";
        lblExit.Size = new Size(440, 26);
        lblExit.TabIndex = 8;
        lblExit.Text = "Thoát";
        lblExit.TextAlign = ContentAlignment.MiddleCenter;
        lblExit.Click += lblExit_Click;
        // 
        // lblHint
        // 
        lblHint.Font = new Font("Segoe UI", 9F);
        lblHint.ForeColor = Color.FromArgb(120, 130, 145);
        lblHint.Location = new Point(0, 520);
        lblHint.Name = "lblHint";
        lblHint.Size = new Size(440, 24);
        lblHint.TabIndex = 9;
        lblHint.Text = "Tài khoản mẫu: admin / admin123";
        lblHint.TextAlign = ContentAlignment.MiddleCenter;
        // 
        // LoginForm
        // 
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Color.FromArgb(233, 238, 243);
        ClientSize = new Size(480, 610);
        Controls.Add(card);
        Font = new Font("Segoe UI", 10F);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "LoginForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Đăng nhập - Quản lý cơ sở vật chất";
        Shown += LoginForm_Shown;
        card.ResumeLayout(false);
        ResumeLayout(false);
    }

    private CardPanel card;
    private IconCircle logo;
    private Label lblTitle;
    private Label lblSub;
    private Label lblUser;
    private PillTextBox txtUser;
    private Label lblPass;
    private PillTextBox txtPass;
    private Button btnLogin;
    private Label lblExit;
    private Label lblHint;
}
