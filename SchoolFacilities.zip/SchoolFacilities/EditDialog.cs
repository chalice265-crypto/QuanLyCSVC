using System.Data;
using System.Globalization;
using static SchoolFacilities.Theme;

namespace SchoolFacilities;

/// <summary>
/// Hộp thoại thêm/sửa. Khung (tiêu đề, bảng ô nhập, nút Lưu/Hủy) nằm trong EditDialog.Designer.cs;
/// các dòng nhãn + ô nhập được thêm vào bảng tlFields theo danh sách FieldDef.
/// </summary>
public partial class EditDialog : Form
{
    List<FieldDef> _fields = new();
    readonly Dictionary<string, Control> _inputs = new();

    public Dictionary<string, object?> Values { get; } = new();

    /// <summary>Kiểm tra bổ sung trước khi đóng hộp thoại; trả về thông báo lỗi hoặc null.</summary>
    public Func<Dictionary<string, object?>, string?>? Verify { get; set; }

    /// <summary>Constructor không tham số: dành cho Designer.</summary>
    public EditDialog()
    {
        InitializeComponent();
    }

    public EditDialog(string title, List<FieldDef> fields, DataRow? existing = null) : this()
    {
        _fields = fields;
        Text = title;
        lblHeading.Text = title;

        // Kích thước viết theo pixel gốc 96 dpi: form tự co giãn theo DPI (AutoScaleMode.Dpi) khi hiển thị.
        foreach (var f in fields)
        {
            var lbl = new Label
            {
                Text = f.Label + (f.Required ? " *" : ""),
                AutoSize = true,
                ForeColor = Ink,
                Margin = new Padding(0, 9, 8, 0)
            };
            var input = CreateInput(f, existing);
            input.Margin = new Padding(0, 4, 0, 4);
            _inputs[f.Column] = input;
            tlFields.Controls.Add(lbl);
            tlFields.Controls.Add(input);
        }
    }

    Control CreateInput(FieldDef f, DataRow? row)
    {
        object? cur = null;
        if (row != null)
        {
            if (row.Table.Columns.Contains(f.Column) && row[f.Column] != DBNull.Value) cur = row[f.Column];
        }
        else
        {
            cur = f.Default;
        }

        int w = 310;
        switch (f.Kind)
        {
            case FieldKind.Multiline:
                return new TextBox
                {
                    Multiline = true,
                    Height = 74,
                    Width = w,
                    ScrollBars = ScrollBars.Vertical,
                    Text = cur?.ToString() ?? ""
                };

            case FieldKind.Date:
            {
                var dtp = new DateTimePicker
                {
                    Format = DateTimePickerFormat.Short,
                    Width = w,
                    ShowCheckBox = f.AllowNull
                };
                if (cur is DateTime d)
                {
                    dtp.Value = d;
                    dtp.Checked = true;
                }
                else if (f.AllowNull)
                {
                    dtp.Checked = false;
                }
                return dtp;
            }

            case FieldKind.Combo:
            {
                var cb = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = w };
                if (f.ComboSql != null)
                {
                    var dt = Db.Query(f.ComboSql);
                    if (f.AllowNull)
                    {
                        var empty = dt.NewRow();
                        empty["Id"] = DBNull.Value;
                        empty["Name"] = "";
                        dt.Rows.InsertAt(empty, 0);
                    }
                    cb.DataSource = dt;
                    cb.DisplayMember = "Name";
                    cb.ValueMember = "Id";
                    if (cur != null) cb.SelectedValue = cur;
                    else if (cb.Items.Count > 0) cb.SelectedIndex = 0;
                }
                else if (f.ComboItems != null)
                {
                    cb.Items.AddRange(f.ComboItems);
                    if (cur != null) cb.SelectedItem = cur.ToString();
                    if (cb.SelectedIndex < 0 && cb.Items.Count > 0) cb.SelectedIndex = 0;
                }
                return cb;
            }

            case FieldKind.Bool:
                return new CheckBox
                {
                    Checked = cur is bool b ? b : f.Default is true,
                    Text = "Có",
                    AutoSize = true,
                    BackColor = Color.White
                };

            case FieldKind.Password:
                return new TextBox { Width = w, UseSystemPasswordChar = true };

            default:
                return new TextBox { Width = w, Text = cur?.ToString() ?? "" };
        }
    }

    bool TryCollect()
    {
        Values.Clear();
        foreach (var f in _fields)
        {
            var c = _inputs[f.Column];
            object? v = null;

            switch (f.Kind)
            {
                case FieldKind.Combo:
                {
                    var cb = (ComboBox)c;
                    if (f.ComboSql != null)
                        v = (cb.SelectedValue is null || cb.SelectedValue is DBNull) ? null : cb.SelectedValue;
                    else
                        v = cb.SelectedItem;
                    break;
                }
                case FieldKind.Date:
                {
                    var dtp = (DateTimePicker)c;
                    v = dtp.ShowCheckBox && !dtp.Checked ? null : dtp.Value.Date;
                    break;
                }
                case FieldKind.Bool:
                    v = ((CheckBox)c).Checked;
                    break;
                case FieldKind.Password:
                {
                    var pw = c.Text;
                    v = pw.Length == 0 ? null : pw;
                    break;
                }
                case FieldKind.Int:
                {
                    var t = c.Text.Trim();
                    if (t.Length > 0)
                    {
                        if (!int.TryParse(t, NumberStyles.Integer, CultureInfo.CurrentCulture, out var i))
                            return Fail($"\"{f.Label}\" phải là số nguyên.", c);
                        v = i;
                    }
                    break;
                }
                case FieldKind.Decimal:
                {
                    var t = c.Text.Trim();
                    if (t.Length > 0)
                    {
                        if (!decimal.TryParse(t, NumberStyles.Number, CultureInfo.CurrentCulture, out var m) &&
                            !decimal.TryParse(t, NumberStyles.Number, CultureInfo.InvariantCulture, out m))
                            return Fail($"\"{f.Label}\" phải là số.", c);
                        v = m;
                    }
                    break;
                }
                default:
                {
                    var t = c.Text.Trim();
                    v = t.Length == 0 ? null : t;
                    break;
                }
            }

            if (f.Required && v == null)
                return Fail($"Vui lòng nhập \"{f.Label}\".", c);

            Values[f.Column] = v;
        }
        return true;
    }

    bool Fail(string message, Control c)
    {
        MessageBox.Show(this, message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        c.Focus();
        return false;
    }

    void btnOk_Click(object? sender, EventArgs e)
    {
        if (!TryCollect()) return;
        var error = Verify?.Invoke(Values);
        if (error != null)
        {
            MessageBox.Show(this, error, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        DialogResult = DialogResult.OK;
    }
}
