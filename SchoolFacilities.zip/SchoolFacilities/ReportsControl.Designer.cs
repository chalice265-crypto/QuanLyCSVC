#nullable disable
namespace SchoolFacilities;

partial class ReportsControl
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        card = new CardPanel();
        grid = new DataGridView();
        toolbar = new FlowLayoutPanel();
        cboReport = new ComboBox();
        btnView = new Button();
        btnExport = new Button();
        line = new Panel();
        lblTitle = new Label();
        var gridAltStyle = new DataGridViewCellStyle();
        var gridHeaderStyle = new DataGridViewCellStyle();
        var gridCellStyle = new DataGridViewCellStyle();
        ((System.ComponentModel.ISupportInitialize)grid).BeginInit();
        card.SuspendLayout();
        toolbar.SuspendLayout();
        SuspendLayout();
        // 
        // card
        // 
        card.Controls.Add(grid);
        card.Controls.Add(toolbar);
        card.Controls.Add(line);
        card.Controls.Add(lblTitle);
        card.Dock = DockStyle.Fill;
        card.Location = new Point(16, 12);
        card.Margin = new Padding(0);
        card.Name = "card";
        card.Padding = new Padding(28, 20, 28, 18);
        card.Size = new Size(968, 574);
        card.TabIndex = 0;
        // 
        // grid
        // 
        gridAltStyle.BackColor = Color.FromArgb(246, 248, 251);
        gridHeaderStyle.BackColor = Color.White;
        gridHeaderStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        gridHeaderStyle.ForeColor = Color.FromArgb(55, 65, 81);
        gridHeaderStyle.Padding = new Padding(6, 0, 0, 0);
        gridHeaderStyle.SelectionBackColor = Color.White;
        gridHeaderStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
        gridHeaderStyle.WrapMode = DataGridViewTriState.False;
        gridCellStyle.BackColor = Color.White;
        gridCellStyle.Font = new Font("Segoe UI", 10F);
        gridCellStyle.ForeColor = Color.FromArgb(55, 65, 81);
        gridCellStyle.Padding = new Padding(6, 0, 0, 0);
        gridCellStyle.SelectionBackColor = Color.FromArgb(219, 238, 253);
        gridCellStyle.SelectionForeColor = Color.Black;
        gridCellStyle.WrapMode = DataGridViewTriState.False;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.AlternatingRowsDefaultCellStyle = gridAltStyle;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.BackgroundColor = Color.White;
        grid.BorderStyle = BorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
        grid.ColumnHeadersDefaultCellStyle = gridHeaderStyle;
        grid.ColumnHeadersHeight = 40;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.DefaultCellStyle = gridCellStyle;
        grid.Dock = DockStyle.Fill;
        grid.EnableHeadersVisualStyles = false;
        grid.GridColor = Color.FromArgb(229, 233, 238);
        grid.Location = new Point(28, 124);
        grid.MultiSelect = false;
        grid.Name = "grid";
        grid.ReadOnly = true;
        grid.RowHeadersVisible = false;
        grid.RowTemplate.Height = 36;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.TabIndex = 3;
        grid.CellFormatting += grid_CellFormatting;
        // 
        // toolbar
        // 
        toolbar.Controls.Add(cboReport);
        toolbar.Controls.Add(btnView);
        toolbar.Controls.Add(btnExport);
        toolbar.Dock = DockStyle.Top;
        toolbar.Location = new Point(28, 62);
        toolbar.Name = "toolbar";
        toolbar.Padding = new Padding(0, 12, 0, 6);
        toolbar.Size = new Size(912, 62);
        toolbar.TabIndex = 2;
        toolbar.WrapContents = false;
        // 
        // cboReport
        // 
        cboReport.DropDownStyle = ComboBoxStyle.DropDownList;
        cboReport.FlatStyle = FlatStyle.Flat;
        cboReport.Items.AddRange(new object[] {
            "Thiết bị theo phòng",
            "Thiết bị theo loại và tình trạng",
            "Thiết bị hỏng và đang bảo trì",
            "Lịch sử điều chuyển",
            "Chi phí bảo trì theo tháng"});
        cboReport.Location = new Point(0, 17);
        cboReport.Margin = new Padding(0, 5, 16, 0);
        cboReport.Name = "cboReport";
        cboReport.Size = new Size(320, 28);
        cboReport.TabIndex = 0;
        cboReport.SelectedIndexChanged += cboReport_SelectedIndexChanged;
        // 
        // btnView
        // 
        btnView.AutoSize = true;
        btnView.BackColor = Color.FromArgb(24, 160, 245);
        btnView.Cursor = Cursors.Hand;
        btnView.FlatAppearance.BorderSize = 0;
        btnView.FlatAppearance.MouseOverBackColor = Color.FromArgb(59, 176, 246);
        btnView.FlatStyle = FlatStyle.Flat;
        btnView.ForeColor = Color.White;
        btnView.Margin = new Padding(0, 0, 8, 0);
        btnView.MinimumSize = new Size(88, 36);
        btnView.Name = "btnView";
        btnView.Padding = new Padding(10, 0, 10, 0);
        btnView.Size = new Size(120, 36);
        btnView.TabIndex = 1;
        btnView.Text = "Xem báo cáo";
        btnView.UseVisualStyleBackColor = false;
        btnView.Click += btnView_Click;
        // 
        // btnExport
        // 
        btnExport.AutoSize = true;
        btnExport.BackColor = Color.FromArgb(16, 185, 129);
        btnExport.Cursor = Cursors.Hand;
        btnExport.FlatAppearance.BorderSize = 0;
        btnExport.FlatAppearance.MouseOverBackColor = Color.FromArgb(53, 196, 148);
        btnExport.FlatStyle = FlatStyle.Flat;
        btnExport.ForeColor = Color.White;
        btnExport.Margin = new Padding(0, 0, 8, 0);
        btnExport.MinimumSize = new Size(88, 36);
        btnExport.Name = "btnExport";
        btnExport.Padding = new Padding(10, 0, 10, 0);
        btnExport.Size = new Size(150, 36);
        btnExport.TabIndex = 2;
        btnExport.Text = "Xuất CSV (Excel)";
        btnExport.UseVisualStyleBackColor = false;
        btnExport.Click += btnExport_Click;
        // 
        // line
        // 
        line.BackColor = Color.FromArgb(229, 233, 238);
        line.Dock = DockStyle.Top;
        line.Location = new Point(28, 61);
        line.Name = "line";
        line.Size = new Size(912, 1);
        line.TabIndex = 1;
        // 
        // lblTitle
        // 
        lblTitle.Dock = DockStyle.Top;
        lblTitle.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitle.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitle.Location = new Point(28, 20);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(912, 42);
        lblTitle.TabIndex = 0;
        lblTitle.Text = "Báo cáo thống kê";
        lblTitle.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // ReportsControl
        // 
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Color.FromArgb(233, 238, 243);
        Controls.Add(card);
        Font = new Font("Segoe UI", 10F);
        Name = "ReportsControl";
        Padding = new Padding(16, 12, 16, 14);
        Size = new Size(1000, 600);
        ((System.ComponentModel.ISupportInitialize)grid).EndInit();
        card.ResumeLayout(false);
        toolbar.ResumeLayout(false);
        toolbar.PerformLayout();
        ResumeLayout(false);
    }

    private CardPanel card;
    private DataGridView grid;
    private FlowLayoutPanel toolbar;
    private ComboBox cboReport;
    private Button btnView;
    private Button btnExport;
    private Panel line;
    private Label lblTitle;
}
