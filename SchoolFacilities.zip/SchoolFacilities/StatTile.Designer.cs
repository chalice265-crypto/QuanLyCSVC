namespace SchoolFacilities;

partial class StatTile
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    #region Component Designer generated code

    private void InitializeComponent()
    {
        lblCaption = new Label();
        lblValue = new Label();
        lblLink = new Label();
        picIcon = new Panel();
        SuspendLayout();
        // 
        // lblCaption
        // 
        lblCaption.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        lblCaption.AutoEllipsis = true;
        lblCaption.BackColor = Color.Transparent;
        lblCaption.Font = new Font("Segoe UI", 10F);
        lblCaption.Location = new Point(14, 14);
        lblCaption.Name = "lblCaption";
        lblCaption.Size = new Size(104, 40);
        lblCaption.TabIndex = 0;
        lblCaption.Text = "Tiêu đề";
        // 
        // lblValue
        // 
        lblValue.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        lblValue.AutoEllipsis = true;
        lblValue.BackColor = Color.Transparent;
        lblValue.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold);
        lblValue.Location = new Point(12, 58);
        lblValue.Name = "lblValue";
        lblValue.Size = new Size(165, 46);
        lblValue.TabIndex = 1;
        lblValue.Text = "0";
        lblValue.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // lblLink
        // 
        lblLink.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lblLink.BackColor = Color.Transparent;
        lblLink.Font = new Font("Segoe UI", 9.5F);
        lblLink.Location = new Point(14, 110);
        lblLink.Name = "lblLink";
        lblLink.Size = new Size(160, 20);
        lblLink.TabIndex = 2;
        lblLink.Text = "Xem chi tiết";
        // 
        // picIcon
        // 
        picIcon.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        picIcon.BackColor = Color.Transparent;
        picIcon.Location = new Point(124, 12);
        picIcon.Name = "picIcon";
        picIcon.Size = new Size(52, 52);
        picIcon.TabIndex = 3;
        picIcon.Paint += picIcon_Paint;
        // 
        // StatTile
        // 
        AutoScaleMode = AutoScaleMode.None;
        Controls.Add(picIcon);
        Controls.Add(lblLink);
        Controls.Add(lblValue);
        Controls.Add(lblCaption);
        Name = "StatTile";
        Size = new Size(189, 140);
        ResumeLayout(false);
    }

    #endregion

    private Label lblCaption;
    private Label lblValue;
    private Label lblLink;
    private Panel picIcon;
}
