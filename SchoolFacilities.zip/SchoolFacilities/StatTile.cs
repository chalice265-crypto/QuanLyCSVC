using System.ComponentModel;
using System.Drawing.Drawing2D;

namespace SchoolFacilities;

/// <summary>
/// Ô thống kê (số lớn + tiêu đề + liên kết "Xem chi tiết").
/// Chữ là Label thật nên chỉnh vị trí / cỡ chữ trực tiếp trong Designer của StatTile.
/// </summary>
public partial class StatTile : UserControl
{
    Color _back = Color.FromArgb(200, 238, 252);
    Color _fore = Color.FromArgb(14, 150, 215);
    IconKind _kind = IconKind.Device;

    public StatTile()
    {
        InitializeComponent();
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                 ControlStyles.SupportsTransparentBackColor, true);
        Cursor = Cursors.Hand;
        ApplyFore();

        // Click ở bất kỳ chữ / icon nào cũng tính là click vào ô.
        foreach (Control c in Controls)
        {
            c.Cursor = Cursors.Hand;
            c.Click += (s, e) => OnClick(e);
        }
    }

    // ================= Thuộc tính (giữ nguyên tên như StatTile cũ) =================

    [Category("StatTile"), DefaultValue("")]
    public string Caption { get => lblCaption.Text; set => lblCaption.Text = value; }

    [Category("StatTile"), DefaultValue("0")]
    public string Value { get => lblValue.Text; set => lblValue.Text = value; }

    [Category("StatTile"), DefaultValue("")]
    public string LinkText { get => lblLink.Text; set => lblLink.Text = value; }

    /// <summary>Màu nền của ô.</summary>
    [Category("StatTile")]
    public Color Back
    {
        get => _back;
        set { _back = value; Invalidate(); }
    }

    /// <summary>Màu chữ / icon.</summary>
    [Category("StatTile")]
    public Color Fore
    {
        get => _fore;
        set { _fore = value; ApplyFore(); Invalidate(); }
    }

    [Category("StatTile"), DefaultValue(IconKind.Device)]
    public IconKind Kind
    {
        get => _kind;
        set { _kind = value; picIcon.Invalidate(); }
    }

    void ApplyFore()
    {
        lblCaption.ForeColor = _fore;
        lblValue.ForeColor = _fore;
        lblLink.ForeColor = _fore;
        picIcon.Invalidate();
    }

    // ================= Vẽ nền bo góc =================

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        // Nền ngoài (màu của control cha) để các góc bo trông sạch.
        using (var bg = new SolidBrush(Parent?.BackColor ?? BackColor))
            g.FillRectangle(bg, ClientRectangle);

        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = RoundedRect(rect, 14);
        using var fill = new SolidBrush(_back);
        g.FillPath(fill, path);
    }

    static GraphicsPath RoundedRect(Rectangle r, int radius)
    {
        int d = radius * 2;
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    // ================= Vẽ icon (vòng tròn + biểu tượng) =================

    void picIcon_Paint(object? sender, PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        var r = new Rectangle(1, 1, picIcon.Width - 3, picIcon.Height - 3);
        using (var fill = new SolidBrush(Color.FromArgb(230, Color.White)))
            g.FillEllipse(fill, r);
        using (var pen = new Pen(_fore, 2f))
            g.DrawEllipse(pen, r);

        // TODO: nếu StatTile cũ trong Controls.cs có hàm vẽ icon riêng (ví dụ Icons.Draw(g, kind, rect, color)),
        // hãy gọi hàm đó ở đây thay cho DrawGlyph để icon giống hệt trước đây.
        DrawGlyph(g, r);
    }

    void DrawGlyph(Graphics g, Rectangle r)
    {
        // Biểu tượng tạm bằng font Segoe MDL2 Assets (có sẵn trên Windows 10/11).
        string glyph = _kind switch
        {
            IconKind.Device => "\uE7F4",
            IconKind.Wrench => "\uE90F",
            IconKind.Key => "\uE8D7",
            _ => "\uE946",
        };
        using var f = new Font("Segoe MDL2 Assets", r.Height * 0.42f, FontStyle.Regular, GraphicsUnit.Pixel);
        using var br = new SolidBrush(_fore);
        using var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        g.DrawString(glyph, f, br, r, sf);
    }
}
