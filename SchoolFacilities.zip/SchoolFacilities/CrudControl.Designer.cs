#nullable disable
namespace SchoolFacilities;

partial class CrudControl
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        card = new CardPanel();
        grid = new DataGridView();
        toolbar = new FlowLayoutPanel();
        txtSearch = new PillTextBox();
        btnAdd = new Button();
        btnEdit = new Button();
        btnDelete = new Button();
        btnRefresh = new Button();
        btnTransfer = new Button();
        btnBroken = new Button();
        btnComplete = new Button();
        line = new Panel();
        lblTitle = new Label();
        var gridAltStyle = new DataGridViewCellStyle();
        var gridHeaderStyle = new DataGridViewCellStyle();
        var gridCellStyle = new DataGridViewCellStyle();
        ((System.ComponentModel.ISupportInitialize)grid).BeginInit();
        card.SuspendLayout();
        toolbar.SuspendLayout();
        SuspendLayout();
        // 
        // card
        // 
        card.Controls.Add(grid);
        card.Controls.Add(toolbar);
        card.Controls.Add(line);
        card.Controls.Add(lblTitle);
        card.Dock = DockStyle.Fill;
        card.Location = new Point(16, 12);
        card.Margin = new Padding(0);
        card.Name = "card";
        card.Padding = new Padding(28, 20, 28, 18);
        card.Size = new Size(968, 574);
        card.TabIndex = 0;
        // 
        // grid
        // 
        gridAltStyle.BackColor = Color.FromArgb(246, 248, 251);
        gridHeaderStyle.BackColor = Color.White;
        gridHeaderStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        gridHeaderStyle.ForeColor = Color.FromArgb(55, 65, 81);
        gridHeaderStyle.Padding = new Padding(6, 0, 0, 0);
        gridHeaderStyle.SelectionBackColor = Color.White;
        gridHeaderStyle.SelectionForeColor = Color.FromArgb(55, 65, 81);
        gridHeaderStyle.WrapMode = DataGridViewTriState.False;
        gridCellStyle.BackColor = Color.White;
        gridCellStyle.Font = new Font("Segoe UI", 10F);
        gridCellStyle.ForeColor = Color.FromArgb(55, 65, 81);
        gridCellStyle.Padding = new Padding(6, 0, 0, 0);
        gridCellStyle.SelectionBackColor = Color.FromArgb(219, 238, 253);
        gridCellStyle.SelectionForeColor = Color.Black;
        gridCellStyle.WrapMode = DataGridViewTriState.False;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.AlternatingRowsDefaultCellStyle = gridAltStyle;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.BackgroundColor = Color.White;
        grid.BorderStyle = BorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
        grid.ColumnHeadersDefaultCellStyle = gridHeaderStyle;
        grid.ColumnHeadersHeight = 40;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.DefaultCellStyle = gridCellStyle;
        grid.Dock = DockStyle.Fill;
        grid.EnableHeadersVisualStyles = false;
        grid.GridColor = Color.FromArgb(229, 233, 238);
        grid.Location = new Point(28, 124);
        grid.MultiSelect = false;
        grid.Name = "grid";
        grid.ReadOnly = true;
        grid.RowHeadersVisible = false;
        grid.RowTemplate.Height = 36;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.TabIndex = 3;
        grid.CellDoubleClick += grid_CellDoubleClick;
        grid.CellFormatting += grid_CellFormatting;
        // 
        // toolbar
        // 
        toolbar.Controls.Add(txtSearch);
        toolbar.Controls.Add(btnAdd);
        toolbar.Controls.Add(btnEdit);
        toolbar.Controls.Add(btnDelete);
        toolbar.Controls.Add(btnRefresh);
        toolbar.Controls.Add(btnTransfer);
        toolbar.Controls.Add(btnBroken);
        toolbar.Controls.Add(btnComplete);
        toolbar.Dock = DockStyle.Top;
        toolbar.Location = new Point(28, 62);
        toolbar.Name = "toolbar";
        toolbar.Padding = new Padding(0, 12, 0, 6);
        toolbar.Size = new Size(912, 62);
        toolbar.TabIndex = 2;
        toolbar.WrapContents = false;
        // 
        // txtSearch
        // 
        txtSearch.Location = new Point(0, 12);
        txtSearch.Margin = new Padding(0, 0, 16, 0);
        txtSearch.Name = "txtSearch";
        txtSearch.PlaceholderText = "Tìm kiếm...";
        txtSearch.RightIcon = IconKind.Search;
        txtSearch.Size = new Size(280, 38);
        txtSearch.TabIndex = 0;
        txtSearch.TextChanged += txtSearch_TextChanged;
        // 
        // btnAdd
        // 
        btnAdd.AutoSize = true;
        btnAdd.BackColor = Color.FromArgb(24, 160, 245);
        btnAdd.Cursor = Cursors.Hand;
        btnAdd.FlatAppearance.BorderSize = 0;
        btnAdd.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 174, 247);
        btnAdd.FlatStyle = FlatStyle.Flat;
        btnAdd.ForeColor = Color.White;
        btnAdd.Margin = new Padding(0, 0, 8, 0);
        btnAdd.MinimumSize = new Size(88, 36);
        btnAdd.Name = "btnAdd";
        btnAdd.Padding = new Padding(10, 0, 10, 0);
        btnAdd.Size = new Size(88, 36);
        btnAdd.TabIndex = 1;
        btnAdd.Text = "Thêm mới";
        btnAdd.UseVisualStyleBackColor = false;
        btnAdd.Click += btnAdd_Click;
        // 
        // btnEdit
        // 
        btnEdit.AutoSize = true;
        btnEdit.BackColor = Color.FromArgb(20, 160, 150);
        btnEdit.Cursor = Cursors.Hand;
        btnEdit.FlatAppearance.BorderSize = 0;
        btnEdit.FlatAppearance.MouseOverBackColor = Color.FromArgb(55, 174, 165);
        btnEdit.FlatStyle = FlatStyle.Flat;
        btnEdit.ForeColor = Color.White;
        btnEdit.Margin = new Padding(0, 0, 8, 0);
        btnEdit.MinimumSize = new Size(88, 36);
        btnEdit.Name = "btnEdit";
        btnEdit.Padding = new Padding(10, 0, 10, 0);
        btnEdit.Size = new Size(88, 36);
        btnEdit.TabIndex = 2;
        btnEdit.Text = "Sửa";
        btnEdit.UseVisualStyleBackColor = false;
        btnEdit.Click += btnEdit_Click;
        // 
        // btnDelete
        // 
        btnDelete.AutoSize = true;
        btnDelete.BackColor = Color.FromArgb(220, 53, 69);
        btnDelete.Cursor = Cursors.Hand;
        btnDelete.FlatAppearance.BorderSize = 0;
        btnDelete.FlatAppearance.MouseOverBackColor = Color.FromArgb(225, 83, 97);
        btnDelete.FlatStyle = FlatStyle.Flat;
        btnDelete.ForeColor = Color.White;
        btnDelete.Margin = new Padding(0, 0, 8, 0);
        btnDelete.MinimumSize = new Size(88, 36);
        btnDelete.Name = "btnDelete";
        btnDelete.Padding = new Padding(10, 0, 10, 0);
        btnDelete.Size = new Size(88, 36);
        btnDelete.TabIndex = 3;
        btnDelete.Text = "Xóa";
        btnDelete.UseVisualStyleBackColor = false;
        btnDelete.Click += btnDelete_Click;
        // 
        // btnRefresh
        // 
        btnRefresh.AutoSize = true;
        btnRefresh.BackColor = Color.FromArgb(100, 116, 139);
        btnRefresh.Cursor = Cursors.Hand;
        btnRefresh.FlatAppearance.BorderSize = 0;
        btnRefresh.FlatAppearance.MouseOverBackColor = Color.FromArgb(123, 137, 157);
        btnRefresh.FlatStyle = FlatStyle.Flat;
        btnRefresh.ForeColor = Color.White;
        btnRefresh.Margin = new Padding(0, 0, 8, 0);
        btnRefresh.MinimumSize = new Size(88, 36);
        btnRefresh.Name = "btnRefresh";
        btnRefresh.Padding = new Padding(10, 0, 10, 0);
        btnRefresh.Size = new Size(88, 36);
        btnRefresh.TabIndex = 4;
        btnRefresh.Text = "Làm mới";
        btnRefresh.UseVisualStyleBackColor = false;
        btnRefresh.Click += btnRefresh_Click;
        // 
        // btnTransfer
        // 
        btnTransfer.AutoSize = true;
        btnTransfer.BackColor = Color.FromArgb(99, 102, 241);
        btnTransfer.Cursor = Cursors.Hand;
        btnTransfer.FlatAppearance.BorderSize = 0;
        btnTransfer.FlatAppearance.MouseOverBackColor = Color.FromArgb(122, 125, 243);
        btnTransfer.FlatStyle = FlatStyle.Flat;
        btnTransfer.ForeColor = Color.White;
        btnTransfer.Margin = new Padding(0, 0, 8, 0);
        btnTransfer.MinimumSize = new Size(88, 36);
        btnTransfer.Name = "btnTransfer";
        btnTransfer.Padding = new Padding(10, 0, 10, 0);
        btnTransfer.Size = new Size(88, 36);
        btnTransfer.TabIndex = 5;
        btnTransfer.Text = "Điều chuyển phòng";
        btnTransfer.UseVisualStyleBackColor = false;
        btnTransfer.Visible = false;
        // 
        // btnBroken
        // 
        btnBroken.AutoSize = true;
        btnBroken.BackColor = Color.FromArgb(245, 158, 11);
        btnBroken.Cursor = Cursors.Hand;
        btnBroken.FlatAppearance.BorderSize = 0;
        btnBroken.FlatAppearance.MouseOverBackColor = Color.FromArgb(246, 173, 48);
        btnBroken.FlatStyle = FlatStyle.Flat;
        btnBroken.ForeColor = Color.White;
        btnBroken.Margin = new Padding(0, 0, 8, 0);
        btnBroken.MinimumSize = new Size(88, 36);
        btnBroken.Name = "btnBroken";
        btnBroken.Padding = new Padding(10, 0, 10, 0);
        btnBroken.Size = new Size(88, 36);
        btnBroken.TabIndex = 6;
        btnBroken.Text = "Báo hỏng";
        btnBroken.UseVisualStyleBackColor = false;
        btnBroken.Visible = false;
        // 
        // btnComplete
        // 
        btnComplete.AutoSize = true;
        btnComplete.BackColor = Color.FromArgb(16, 185, 129);
        btnComplete.Cursor = Cursors.Hand;
        btnComplete.FlatAppearance.BorderSize = 0;
        btnComplete.FlatAppearance.MouseOverBackColor = Color.FromArgb(52, 196, 148);
        btnComplete.FlatStyle = FlatStyle.Flat;
        btnComplete.ForeColor = Color.White;
        btnComplete.Margin = new Padding(0, 0, 8, 0);
        btnComplete.MinimumSize = new Size(88, 36);
        btnComplete.Name = "btnComplete";
        btnComplete.Padding = new Padding(10, 0, 10, 0);
        btnComplete.Size = new Size(88, 36);
        btnComplete.TabIndex = 7;
        btnComplete.Text = "Đánh dấu hoàn thành";
        btnComplete.UseVisualStyleBackColor = false;
        btnComplete.Visible = false;
        // 
        // line
        // 
        line.BackColor = Color.FromArgb(229, 233, 238);
        line.Dock = DockStyle.Top;
        line.Location = new Point(28, 61);
        line.Name = "line";
        line.Size = new Size(912, 1);
        line.TabIndex = 1;
        // 
        // lblTitle
        // 
        lblTitle.Dock = DockStyle.Top;
        lblTitle.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitle.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitle.Location = new Point(28, 20);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(912, 42);
        lblTitle.TabIndex = 0;
        lblTitle.Text = "Tiêu đề trang";
        lblTitle.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // CrudControl
        // 
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Color.FromArgb(233, 238, 243);
        Controls.Add(card);
        Dock = DockStyle.Fill;
        Font = new Font("Segoe UI", 10F);
        Name = "CrudControl";
        Padding = new Padding(16, 12, 16, 14);
        Size = new Size(1000, 600);
        ((System.ComponentModel.ISupportInitialize)grid).EndInit();
        card.ResumeLayout(false);
        toolbar.ResumeLayout(false);
        toolbar.PerformLayout();
        ResumeLayout(false);
    }

    private CardPanel card;
    private DataGridView grid;
    private FlowLayoutPanel toolbar;
    private PillTextBox txtSearch;
    private Button btnAdd;
    private Button btnEdit;
    private Button btnDelete;
    private Button btnRefresh;
    private Button btnTransfer;
    private Button btnBroken;
    private Button btnComplete;
    private Panel line;
    private Label lblTitle;
}
