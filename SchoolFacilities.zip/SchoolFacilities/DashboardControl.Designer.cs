#nullable disable
namespace SchoolFacilities;

partial class DashboardControl
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        pnlScroll = new Panel();
        tlRoot = new TableLayoutPanel();
        tlRow1 = new TableLayoutPanel();
        cardInfo = new SchoolFacilities.CardPanel();
        bodyInfo = new Panel();
        tlInfo = new TableLayoutPanel();
        pnlAvatar = new TableLayoutPanel();
        circleInfo = new SchoolFacilities.IconCircle();
        lnkInfoMore = new Label();
        infoLeft = new SchoolFacilities.KeyValueList();
        infoRight = new SchoolFacilities.KeyValueList();
        gapInfo = new Panel();
        lineInfo = new Panel();
        headInfo = new Panel();
        lblTitleInfo = new Label();
        lnkInfoEdit = new Label();
        tlRight = new TableLayoutPanel();
        cardRemind = new SchoolFacilities.CardPanel();
        tlRemind = new TableLayoutPanel();
        pnlRemindLeft = new Panel();
        lnkRemindMore = new Label();
        lblRemindNumber = new Label();
        lblRemindText = new Label();
        pnlBell = new Panel();
        circleBell = new SchoolFacilities.IconCircle();
        lblRemindCaption = new Label();
        tlTiles = new TableLayoutPanel();
        tileTotal = new StatTile();
        tileAttention = new StatTile();
        tlShortcuts = new TableLayoutPanel();
        tileBuildings = new SchoolFacilities.ShortcutTile();
        tileRooms = new SchoolFacilities.ShortcutTile();
        tileTypes = new SchoolFacilities.ShortcutTile();
        tileEquipment = new SchoolFacilities.ShortcutTile();
        tileMaintenance = new SchoolFacilities.ShortcutTile();
        tileReports = new SchoolFacilities.ShortcutTile();
        tileLast = new SchoolFacilities.ShortcutTile();
        tlRow3 = new TableLayoutPanel();
        cardDonut = new SchoolFacilities.CardPanel();
        bodyDonut = new Panel();
        donut = new SchoolFacilities.DonutChart();
        gapDonut = new Panel();
        lineDonut = new Panel();
        headDonut = new Panel();
        lblTitleDonut = new Label();
        cardBars = new SchoolFacilities.CardPanel();
        bodyBars = new Panel();
        bars = new SchoolFacilities.BarChart();
        gapBars = new Panel();
        lineBars = new Panel();
        headBars = new Panel();
        lblTitleBars = new Label();
        cboBuilding = new ComboBox();
        cardList = new SchoolFacilities.CardPanel();
        bodyList = new Panel();
        pnlList = new Panel();
        lblListEmpty = new Label();
        row5 = new SchoolFacilities.ListRow();
        row4 = new SchoolFacilities.ListRow();
        row3 = new SchoolFacilities.ListRow();
        row2 = new SchoolFacilities.ListRow();
        row1 = new SchoolFacilities.ListRow();
        rowHeader = new SchoolFacilities.ListRow();
        gapList = new Panel();
        lineList = new Panel();
        headList = new Panel();
        lblTitleList = new Label();
        pnlScroll.SuspendLayout();
        tlRoot.SuspendLayout();
        tlRow1.SuspendLayout();
        cardInfo.SuspendLayout();
        bodyInfo.SuspendLayout();
        tlInfo.SuspendLayout();
        pnlAvatar.SuspendLayout();
        headInfo.SuspendLayout();
        tlRight.SuspendLayout();
        cardRemind.SuspendLayout();
        tlRemind.SuspendLayout();
        pnlRemindLeft.SuspendLayout();
        pnlBell.SuspendLayout();
        tlTiles.SuspendLayout();
        tlShortcuts.SuspendLayout();
        tlRow3.SuspendLayout();
        cardDonut.SuspendLayout();
        bodyDonut.SuspendLayout();
        headDonut.SuspendLayout();
        cardBars.SuspendLayout();
        bodyBars.SuspendLayout();
        headBars.SuspendLayout();
        cardList.SuspendLayout();
        bodyList.SuspendLayout();
        pnlList.SuspendLayout();
        headList.SuspendLayout();
        SuspendLayout();
        // 
        // pnlScroll
        // 
        pnlScroll.AutoScroll = true;
        pnlScroll.BackColor = Color.FromArgb(233, 238, 243);
        pnlScroll.Controls.Add(tlRoot);
        pnlScroll.Dock = DockStyle.Fill;
        pnlScroll.Location = new Point(0, 0);
        pnlScroll.Name = "pnlScroll";
        pnlScroll.Size = new Size(1025, 580);
        pnlScroll.TabIndex = 0;
        // 
        // tlRoot
        // 
        tlRoot.BackColor = Color.FromArgb(233, 238, 243);
        tlRoot.ColumnCount = 1;
        tlRoot.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        tlRoot.Controls.Add(tlRow1, 0, 0);
        tlRoot.Controls.Add(tlShortcuts, 0, 1);
        tlRoot.Controls.Add(tlRow3, 0, 2);
        tlRoot.Dock = DockStyle.Top;
        tlRoot.Location = new Point(0, 0);
        tlRoot.Name = "tlRoot";
        tlRoot.Padding = new Padding(14, 10, 14, 14);
        tlRoot.RowCount = 3;
        tlRoot.RowStyles.Add(new RowStyle(SizeType.Absolute, 300F));
        tlRoot.RowStyles.Add(new RowStyle(SizeType.Absolute, 140F));
        tlRoot.RowStyles.Add(new RowStyle(SizeType.Absolute, 410F));
        tlRoot.Size = new Size(1004, 874);
        tlRoot.TabIndex = 0;
        // 
        // tlRow1
        // 
        tlRow1.BackColor = Color.FromArgb(233, 238, 243);
        tlRow1.ColumnCount = 2;
        tlRow1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58F));
        tlRow1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42F));
        tlRow1.Controls.Add(cardInfo, 0, 0);
        tlRow1.Controls.Add(tlRight, 1, 0);
        tlRow1.Dock = DockStyle.Fill;
        tlRow1.Location = new Point(14, 10);
        tlRow1.Margin = new Padding(0);
        tlRow1.Name = "tlRow1";
        tlRow1.RowCount = 1;
        tlRow1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlRow1.Size = new Size(976, 300);
        tlRow1.TabIndex = 0;
        // 
        // cardInfo
        // 
        cardInfo.BackColor = Color.FromArgb(233, 238, 243);
        cardInfo.Controls.Add(bodyInfo);
        cardInfo.Controls.Add(gapInfo);
        cardInfo.Controls.Add(lineInfo);
        cardInfo.Controls.Add(headInfo);
        cardInfo.Dock = DockStyle.Fill;
        cardInfo.FillColor = Color.White;
        cardInfo.Location = new Point(8, 8);
        cardInfo.Margin = new Padding(8);
        cardInfo.Name = "cardInfo";
        cardInfo.Padding = new Padding(28, 20, 28, 18);
        cardInfo.Radius = 8;
        cardInfo.Size = new Size(550, 284);
        cardInfo.TabIndex = 1;
        // 
        // bodyInfo
        // 
        bodyInfo.BackColor = Color.White;
        bodyInfo.Controls.Add(tlInfo);
        bodyInfo.Dock = DockStyle.Fill;
        bodyInfo.Location = new Point(28, 75);
        bodyInfo.Name = "bodyInfo";
        bodyInfo.Size = new Size(494, 191);
        bodyInfo.TabIndex = 3;
        // 
        // tlInfo
        // 
        tlInfo.ColumnCount = 3;
        tlInfo.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170F));
        tlInfo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        tlInfo.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        tlInfo.Controls.Add(pnlAvatar, 0, 0);
        tlInfo.Controls.Add(infoLeft, 1, 0);
        tlInfo.Controls.Add(infoRight, 2, 0);
        tlInfo.Dock = DockStyle.Fill;
        tlInfo.Location = new Point(0, 0);
        tlInfo.Margin = new Padding(0);
        tlInfo.Name = "tlInfo";
        tlInfo.RowCount = 1;
        tlInfo.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlInfo.Size = new Size(494, 191);
        tlInfo.TabIndex = 0;
        // 
        // pnlAvatar
        // 
        pnlAvatar.ColumnCount = 1;
        pnlAvatar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        pnlAvatar.Controls.Add(circleInfo, 0, 0);
        pnlAvatar.Controls.Add(lnkInfoMore, 0, 1);
        pnlAvatar.Dock = DockStyle.Fill;
        pnlAvatar.Location = new Point(0, 0);
        pnlAvatar.Margin = new Padding(0);
        pnlAvatar.Name = "pnlAvatar";
        pnlAvatar.RowCount = 2;
        pnlAvatar.RowStyles.Add(new RowStyle(SizeType.Absolute, 136F));
        pnlAvatar.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        pnlAvatar.Size = new Size(170, 191);
        pnlAvatar.TabIndex = 0;
        // 
        // circleInfo
        // 
        circleInfo.Anchor = AnchorStyles.Top;
        circleInfo.Fill = Color.FromArgb(24, 160, 245);
        circleInfo.IconColor = Color.White;
        circleInfo.Kind = IconKind.Building;
        circleInfo.Location = new Point(20, 2);
        circleInfo.Margin = new Padding(0, 2, 0, 0);
        circleInfo.Name = "circleInfo";
        circleInfo.Size = new Size(130, 130);
        circleInfo.Stroke = Color.FromArgb(24, 160, 245);
        circleInfo.TabIndex = 0;
        // 
        // lnkInfoMore
        // 
        lnkInfoMore.Anchor = AnchorStyles.Top;
        lnkInfoMore.AutoSize = true;
        lnkInfoMore.Cursor = Cursors.Hand;
        lnkInfoMore.Font = new Font("Segoe UI", 10.5F);
        lnkInfoMore.ForeColor = Color.FromArgb(24, 160, 245);
        lnkInfoMore.Location = new Point(32, 142);
        lnkInfoMore.Margin = new Padding(0, 6, 0, 0);
        lnkInfoMore.Name = "lnkInfoMore";
        lnkInfoMore.Size = new Size(105, 25);
        lnkInfoMore.TabIndex = 1;
        lnkInfoMore.Text = "Xem chi tiết";
        lnkInfoMore.Click += lnkInfoMore_Click;
        // 
        // infoLeft
        // 
        infoLeft.Dock = DockStyle.Fill;
        infoLeft.Location = new Point(173, 3);
        infoLeft.Name = "infoLeft";
        infoLeft.Size = new Size(156, 185);
        infoLeft.TabIndex = 1;
        // 
        // infoRight
        // 
        infoRight.Dock = DockStyle.Fill;
        infoRight.Location = new Point(335, 3);
        infoRight.Name = "infoRight";
        infoRight.Size = new Size(156, 185);
        infoRight.TabIndex = 2;
        // 
        // gapInfo
        // 
        gapInfo.BackColor = Color.White;
        gapInfo.Dock = DockStyle.Top;
        gapInfo.Location = new Point(28, 63);
        gapInfo.Name = "gapInfo";
        gapInfo.Size = new Size(494, 12);
        gapInfo.TabIndex = 2;
        // 
        // lineInfo
        // 
        lineInfo.BackColor = Color.FromArgb(229, 233, 238);
        lineInfo.Dock = DockStyle.Top;
        lineInfo.Location = new Point(28, 62);
        lineInfo.Name = "lineInfo";
        lineInfo.Size = new Size(494, 1);
        lineInfo.TabIndex = 1;
        // 
        // headInfo
        // 
        headInfo.BackColor = Color.White;
        headInfo.Controls.Add(lblTitleInfo);
        headInfo.Controls.Add(lnkInfoEdit);
        headInfo.Dock = DockStyle.Top;
        headInfo.Location = new Point(28, 20);
        headInfo.Name = "headInfo";
        headInfo.Size = new Size(494, 42);
        headInfo.TabIndex = 0;
        // 
        // lblTitleInfo
        // 
        lblTitleInfo.AutoSize = true;
        lblTitleInfo.Dock = DockStyle.Left;
        lblTitleInfo.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitleInfo.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitleInfo.Location = new Point(0, 0);
        lblTitleInfo.Name = "lblTitleInfo";
        lblTitleInfo.Size = new Size(307, 36);
        lblTitleInfo.TabIndex = 0;
        lblTitleInfo.Text = "Thông tin cơ sở vật chất";
        lblTitleInfo.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // lnkInfoEdit
        // 
        lnkInfoEdit.Cursor = Cursors.Hand;
        lnkInfoEdit.Dock = DockStyle.Right;
        lnkInfoEdit.Font = new Font("Segoe UI", 10.5F);
        lnkInfoEdit.ForeColor = Color.FromArgb(24, 160, 245);
        lnkInfoEdit.Location = new Point(404, 0);
        lnkInfoEdit.Name = "lnkInfoEdit";
        lnkInfoEdit.Size = new Size(90, 42);
        lnkInfoEdit.TabIndex = 1;
        lnkInfoEdit.Text = "Cập nhật";
        lnkInfoEdit.TextAlign = ContentAlignment.MiddleRight;
        lnkInfoEdit.Click += lnkInfoEdit_Click;
        // 
        // tlRight
        // 
        tlRight.BackColor = Color.FromArgb(233, 238, 243);
        tlRight.ColumnCount = 1;
        tlRight.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        tlRight.Controls.Add(cardRemind, 0, 0);
        tlRight.Controls.Add(tlTiles, 0, 1);
        tlRight.Dock = DockStyle.Fill;
        tlRight.Location = new Point(566, 0);
        tlRight.Margin = new Padding(0);
        tlRight.Name = "tlRight";
        tlRight.RowCount = 2;
        tlRight.RowStyles.Add(new RowStyle(SizeType.Percent, 48F));
        tlRight.RowStyles.Add(new RowStyle(SizeType.Percent, 52F));
        tlRight.Size = new Size(410, 300);
        tlRight.TabIndex = 1;
        // 
        // cardRemind
        // 
        cardRemind.BackColor = Color.FromArgb(233, 238, 243);
        cardRemind.Controls.Add(tlRemind);
        cardRemind.Controls.Add(lblRemindCaption);
        cardRemind.Dock = DockStyle.Fill;
        cardRemind.FillColor = Color.White;
        cardRemind.Location = new Point(8, 8);
        cardRemind.Margin = new Padding(8);
        cardRemind.Name = "cardRemind";
        cardRemind.Padding = new Padding(30, 16, 24, 12);
        cardRemind.Radius = 8;
        cardRemind.Size = new Size(394, 128);
        cardRemind.TabIndex = 0;
        // 
        // tlRemind
        // 
        tlRemind.BackColor = Color.White;
        tlRemind.ColumnCount = 3;
        tlRemind.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96F));
        tlRemind.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        tlRemind.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 64F));
        tlRemind.Controls.Add(pnlRemindLeft, 0, 0);
        tlRemind.Controls.Add(lblRemindText, 1, 0);
        tlRemind.Controls.Add(pnlBell, 2, 0);
        tlRemind.Dock = DockStyle.Fill;
        tlRemind.Location = new Point(30, 42);
        tlRemind.Margin = new Padding(0);
        tlRemind.Name = "tlRemind";
        tlRemind.RowCount = 1;
        tlRemind.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlRemind.Size = new Size(340, 74);
        tlRemind.TabIndex = 0;
        // 
        // pnlRemindLeft
        // 
        pnlRemindLeft.Controls.Add(lnkRemindMore);
        pnlRemindLeft.Controls.Add(lblRemindNumber);
        pnlRemindLeft.Dock = DockStyle.Fill;
        pnlRemindLeft.Location = new Point(3, 3);
        pnlRemindLeft.Name = "pnlRemindLeft";
        pnlRemindLeft.Size = new Size(90, 68);
        pnlRemindLeft.TabIndex = 0;
        // 
        // lnkRemindMore
        // 
        lnkRemindMore.Cursor = Cursors.Hand;
        lnkRemindMore.Dock = DockStyle.Top;
        lnkRemindMore.Font = new Font("Segoe UI", 10.5F);
        lnkRemindMore.ForeColor = Color.FromArgb(24, 160, 245);
        lnkRemindMore.Location = new Point(0, 54);
        lnkRemindMore.Name = "lnkRemindMore";
        lnkRemindMore.Size = new Size(90, 24);
        lnkRemindMore.TabIndex = 0;
        lnkRemindMore.Text = "Xem chi tiết";
        lnkRemindMore.Click += lnkRemindMore_Click;
        // 
        // lblRemindNumber
        // 
        lblRemindNumber.Dock = DockStyle.Top;
        lblRemindNumber.Font = new Font("Segoe UI Light", 34F);
        lblRemindNumber.ForeColor = Color.FromArgb(55, 65, 81);
        lblRemindNumber.Location = new Point(0, 0);
        lblRemindNumber.Name = "lblRemindNumber";
        lblRemindNumber.Size = new Size(90, 54);
        lblRemindNumber.TabIndex = 1;
        lblRemindNumber.Text = "0";
        lblRemindNumber.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // lblRemindText
        // 
        lblRemindText.AutoEllipsis = true;
        lblRemindText.Dock = DockStyle.Fill;
        lblRemindText.ForeColor = Color.FromArgb(55, 65, 81);
        lblRemindText.Location = new Point(99, 0);
        lblRemindText.Name = "lblRemindText";
        lblRemindText.Size = new Size(174, 74);
        lblRemindText.TabIndex = 1;
        // 
        // pnlBell
        // 
        pnlBell.Controls.Add(circleBell);
        pnlBell.Dock = DockStyle.Fill;
        pnlBell.Location = new Point(279, 3);
        pnlBell.Name = "pnlBell";
        pnlBell.Size = new Size(58, 68);
        pnlBell.TabIndex = 2;
        // 
        // circleBell
        // 
        circleBell.Fill = Color.Empty;
        circleBell.IconColor = Color.FromArgb(55, 65, 81);
        circleBell.Kind = IconKind.Bell;
        circleBell.Location = new Point(10, 2);
        circleBell.Name = "circleBell";
        circleBell.Size = new Size(44, 44);
        circleBell.Stroke = Color.FromArgb(55, 65, 81);
        circleBell.TabIndex = 0;
        // 
        // lblRemindCaption
        // 
        lblRemindCaption.BackColor = Color.White;
        lblRemindCaption.Dock = DockStyle.Top;
        lblRemindCaption.ForeColor = Color.FromArgb(55, 65, 81);
        lblRemindCaption.Location = new Point(30, 16);
        lblRemindCaption.Name = "lblRemindCaption";
        lblRemindCaption.Size = new Size(340, 26);
        lblRemindCaption.TabIndex = 1;
        lblRemindCaption.Text = "Yêu cầu bảo trì chưa hoàn thành";
        lblRemindCaption.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // tlTiles
        // 
        tlTiles.BackColor = Color.FromArgb(233, 238, 243);
        tlTiles.ColumnCount = 2;
        tlTiles.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        tlTiles.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        tlTiles.Controls.Add(tileTotal, 0, 0);
        tlTiles.Controls.Add(tileAttention, 1, 0);
        tlTiles.Dock = DockStyle.Fill;
        tlTiles.Location = new Point(0, 144);
        tlTiles.Margin = new Padding(0);
        tlTiles.Name = "tlTiles";
        tlTiles.RowCount = 1;
        tlTiles.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlTiles.Size = new Size(410, 156);
        tlTiles.TabIndex = 1;
        // 
        // tileTotal
        // 
        tileTotal.Back = Color.FromArgb(200, 238, 252);
        tileTotal.BackColor = Color.FromArgb(233, 238, 243);
        tileTotal.Caption = "Tổng số thiết bị";
        tileTotal.Dock = DockStyle.Fill;
        tileTotal.Fore = Color.FromArgb(14, 150, 215);
        tileTotal.LinkText = "Xem chi tiết";
        tileTotal.Location = new Point(8, 8);
        tileTotal.Margin = new Padding(8);
        tileTotal.Name = "tileTotal";
        tileTotal.Size = new Size(189, 140);
        tileTotal.TabIndex = 0;
        tileTotal.Click += tileTotal_Click;
        // 
        // tileAttention
        // 
        tileAttention.Back = Color.FromArgb(254, 237, 200);
        tileAttention.BackColor = Color.FromArgb(233, 238, 243);
        tileAttention.Caption = "Cần xử lý (hỏng + bảo trì)";
        tileAttention.Dock = DockStyle.Fill;
        tileAttention.Fore = Color.FromArgb(240, 150, 20);
        tileAttention.Kind = IconKind.Wrench;
        tileAttention.LinkText = "Xem chi tiết";
        tileAttention.Location = new Point(213, 8);
        tileAttention.Margin = new Padding(8);
        tileAttention.Name = "tileAttention";
        tileAttention.Size = new Size(189, 140);
        tileAttention.TabIndex = 1;
        tileAttention.Click += tileAttention_Click;
        // 
        // tlShortcuts
        // 
        tlShortcuts.BackColor = Color.FromArgb(233, 238, 243);
        tlShortcuts.ColumnCount = 7;
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2857141F));
        tlShortcuts.Controls.Add(tileBuildings, 0, 0);
        tlShortcuts.Controls.Add(tileRooms, 1, 0);
        tlShortcuts.Controls.Add(tileTypes, 2, 0);
        tlShortcuts.Controls.Add(tileEquipment, 3, 0);
        tlShortcuts.Controls.Add(tileMaintenance, 4, 0);
        tlShortcuts.Controls.Add(tileReports, 5, 0);
        tlShortcuts.Controls.Add(tileLast, 6, 0);
        tlShortcuts.Dock = DockStyle.Fill;
        tlShortcuts.Location = new Point(14, 310);
        tlShortcuts.Margin = new Padding(0);
        tlShortcuts.Name = "tlShortcuts";
        tlShortcuts.RowCount = 1;
        tlShortcuts.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlShortcuts.Size = new Size(976, 140);
        tlShortcuts.TabIndex = 1;
        // 
        // tileBuildings
        // 
        tileBuildings.BackColor = Color.FromArgb(233, 238, 243);
        tileBuildings.Caption = "Tòa nhà";
        tileBuildings.Cursor = Cursors.Hand;
        tileBuildings.Dock = DockStyle.Fill;
        tileBuildings.Kind = IconKind.Building;
        tileBuildings.Location = new Point(8, 8);
        tileBuildings.Margin = new Padding(8);
        tileBuildings.Name = "tileBuildings";
        tileBuildings.Size = new Size(123, 124);
        tileBuildings.TabIndex = 0;
        tileBuildings.Tag = "buildings";
        tileBuildings.Click += this.tileModule_Click;
        // 
        // tileRooms
        // 
        tileRooms.BackColor = Color.FromArgb(233, 238, 243);
        tileRooms.Caption = "Phòng";
        tileRooms.Cursor = Cursors.Hand;
        tileRooms.Dock = DockStyle.Fill;
        tileRooms.Kind = IconKind.Room;
        tileRooms.Location = new Point(147, 8);
        tileRooms.Margin = new Padding(8);
        tileRooms.Name = "tileRooms";
        tileRooms.Size = new Size(123, 124);
        tileRooms.TabIndex = 1;
        tileRooms.Tag = "rooms";
        tileRooms.Click += this.tileModule_Click;
        // 
        // tileTypes
        // 
        tileTypes.BackColor = Color.FromArgb(233, 238, 243);
        tileTypes.Caption = "Loại thiết bị";
        tileTypes.Cursor = Cursors.Hand;
        tileTypes.Dock = DockStyle.Fill;
        tileTypes.Kind = IconKind.Category;
        tileTypes.Location = new Point(286, 8);
        tileTypes.Margin = new Padding(8);
        tileTypes.Name = "tileTypes";
        tileTypes.Size = new Size(123, 124);
        tileTypes.TabIndex = 2;
        tileTypes.Tag = "types";
        tileTypes.Click += this.tileModule_Click;
        // 
        // tileEquipment
        // 
        tileEquipment.BackColor = Color.FromArgb(233, 238, 243);
        tileEquipment.Caption = "Thiết bị";
        tileEquipment.Cursor = Cursors.Hand;
        tileEquipment.Dock = DockStyle.Fill;
        tileEquipment.Kind = IconKind.Device;
        tileEquipment.Location = new Point(425, 8);
        tileEquipment.Margin = new Padding(8);
        tileEquipment.Name = "tileEquipment";
        tileEquipment.Size = new Size(123, 124);
        tileEquipment.TabIndex = 3;
        tileEquipment.Tag = "equipment";
        tileEquipment.Click += this.tileModule_Click;
        // 
        // tileMaintenance
        // 
        tileMaintenance.BackColor = Color.FromArgb(233, 238, 243);
        tileMaintenance.Caption = "Bảo trì";
        tileMaintenance.Cursor = Cursors.Hand;
        tileMaintenance.Dock = DockStyle.Fill;
        tileMaintenance.Kind = IconKind.Wrench;
        tileMaintenance.Location = new Point(564, 8);
        tileMaintenance.Margin = new Padding(8);
        tileMaintenance.Name = "tileMaintenance";
        tileMaintenance.Size = new Size(123, 124);
        tileMaintenance.TabIndex = 4;
        tileMaintenance.Tag = "maintenance";
        tileMaintenance.Click += this.tileModule_Click;
        // 
        // tileReports
        // 
        tileReports.BackColor = Color.FromArgb(233, 238, 243);
        tileReports.Caption = "Báo cáo";
        tileReports.Cursor = Cursors.Hand;
        tileReports.Dock = DockStyle.Fill;
        tileReports.Kind = IconKind.Chart;
        tileReports.Location = new Point(703, 8);
        tileReports.Margin = new Padding(8);
        tileReports.Name = "tileReports";
        tileReports.Size = new Size(123, 124);
        tileReports.TabIndex = 5;
        tileReports.Tag = "reports";
        tileReports.Click += this.tileModule_Click;
        // 
        // tileLast
        // 
        tileLast.BackColor = Color.FromArgb(233, 238, 243);
        tileLast.Caption = "Người dùng";
        tileLast.Cursor = Cursors.Hand;
        tileLast.Dock = DockStyle.Fill;
        tileLast.Kind = IconKind.Users;
        tileLast.Location = new Point(842, 8);
        tileLast.Margin = new Padding(8);
        tileLast.Name = "tileLast";
        tileLast.Size = new Size(126, 124);
        tileLast.TabIndex = 6;
        tileLast.Click += this.tileLast_Click;
        // 
        // tlRow3
        // 
        tlRow3.BackColor = Color.FromArgb(233, 238, 243);
        tlRow3.ColumnCount = 3;
        tlRow3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34F));
        tlRow3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 29F));
        tlRow3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 37F));
        tlRow3.Controls.Add(cardDonut, 0, 0);
        tlRow3.Controls.Add(cardBars, 1, 0);
        tlRow3.Controls.Add(cardList, 2, 0);
        tlRow3.Dock = DockStyle.Fill;
        tlRow3.Location = new Point(14, 450);
        tlRow3.Margin = new Padding(0);
        tlRow3.Name = "tlRow3";
        tlRow3.RowCount = 1;
        tlRow3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        tlRow3.Size = new Size(976, 410);
        tlRow3.TabIndex = 2;
        // 
        // cardDonut
        // 
        cardDonut.BackColor = Color.FromArgb(233, 238, 243);
        cardDonut.Controls.Add(bodyDonut);
        cardDonut.Controls.Add(gapDonut);
        cardDonut.Controls.Add(lineDonut);
        cardDonut.Controls.Add(headDonut);
        cardDonut.Dock = DockStyle.Fill;
        cardDonut.FillColor = Color.White;
        cardDonut.Location = new Point(8, 8);
        cardDonut.Margin = new Padding(8);
        cardDonut.Name = "cardDonut";
        cardDonut.Padding = new Padding(28, 20, 28, 18);
        cardDonut.Radius = 8;
        cardDonut.Size = new Size(315, 394);
        cardDonut.TabIndex = 2;
        // 
        // bodyDonut
        // 
        bodyDonut.BackColor = Color.White;
        bodyDonut.Controls.Add(donut);
        bodyDonut.Dock = DockStyle.Fill;
        bodyDonut.Location = new Point(28, 75);
        bodyDonut.Name = "bodyDonut";
        bodyDonut.Size = new Size(259, 301);
        bodyDonut.TabIndex = 3;
        // 
        // donut
        // 
        donut.CenterCaption = "thiết bị";
        donut.Dock = DockStyle.Fill;
        donut.Location = new Point(0, 0);
        donut.Name = "donut";
        donut.Size = new Size(259, 301);
        donut.TabIndex = 0;
        // 
        // gapDonut
        // 
        gapDonut.BackColor = Color.White;
        gapDonut.Dock = DockStyle.Top;
        gapDonut.Location = new Point(28, 63);
        gapDonut.Name = "gapDonut";
        gapDonut.Size = new Size(259, 12);
        gapDonut.TabIndex = 2;
        // 
        // lineDonut
        // 
        lineDonut.BackColor = Color.FromArgb(229, 233, 238);
        lineDonut.Dock = DockStyle.Top;
        lineDonut.Location = new Point(28, 62);
        lineDonut.Name = "lineDonut";
        lineDonut.Size = new Size(259, 1);
        lineDonut.TabIndex = 1;
        // 
        // headDonut
        // 
        headDonut.BackColor = Color.White;
        headDonut.Controls.Add(lblTitleDonut);
        headDonut.Dock = DockStyle.Top;
        headDonut.Location = new Point(28, 20);
        headDonut.Name = "headDonut";
        headDonut.Size = new Size(259, 42);
        headDonut.TabIndex = 0;
        // 
        // lblTitleDonut
        // 
        lblTitleDonut.AutoSize = true;
        lblTitleDonut.Dock = DockStyle.Left;
        lblTitleDonut.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitleDonut.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitleDonut.Location = new Point(0, 0);
        lblTitleDonut.Name = "lblTitleDonut";
        lblTitleDonut.Size = new Size(299, 36);
        lblTitleDonut.TabIndex = 0;
        lblTitleDonut.Text = "Thiết bị theo tình trạng";
        lblTitleDonut.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // cardBars
        // 
        cardBars.BackColor = Color.FromArgb(233, 238, 243);
        cardBars.Controls.Add(bodyBars);
        cardBars.Controls.Add(gapBars);
        cardBars.Controls.Add(lineBars);
        cardBars.Controls.Add(headBars);
        cardBars.Dock = DockStyle.Fill;
        cardBars.FillColor = Color.White;
        cardBars.Location = new Point(339, 8);
        cardBars.Margin = new Padding(8);
        cardBars.Name = "cardBars";
        cardBars.Padding = new Padding(28, 20, 28, 18);
        cardBars.Radius = 8;
        cardBars.Size = new Size(267, 394);
        cardBars.TabIndex = 3;
        // 
        // bodyBars
        // 
        bodyBars.BackColor = Color.White;
        bodyBars.Controls.Add(bars);
        bodyBars.Dock = DockStyle.Fill;
        bodyBars.Location = new Point(28, 75);
        bodyBars.Name = "bodyBars";
        bodyBars.Size = new Size(211, 301);
        bodyBars.TabIndex = 3;
        // 
        // bars
        // 
        bars.BarColor = Color.FromArgb(24, 160, 245);
        bars.Dock = DockStyle.Fill;
        bars.Location = new Point(0, 0);
        bars.Name = "bars";
        bars.Size = new Size(211, 301);
        bars.TabIndex = 0;
        // 
        // gapBars
        // 
        gapBars.BackColor = Color.White;
        gapBars.Dock = DockStyle.Top;
        gapBars.Location = new Point(28, 63);
        gapBars.Name = "gapBars";
        gapBars.Size = new Size(211, 12);
        gapBars.TabIndex = 2;
        // 
        // lineBars
        // 
        lineBars.BackColor = Color.FromArgb(229, 233, 238);
        lineBars.Dock = DockStyle.Top;
        lineBars.Location = new Point(28, 62);
        lineBars.Name = "lineBars";
        lineBars.Size = new Size(211, 1);
        lineBars.TabIndex = 1;
        // 
        // headBars
        // 
        headBars.BackColor = Color.White;
        headBars.Controls.Add(lblTitleBars);
        headBars.Controls.Add(cboBuilding);
        headBars.Dock = DockStyle.Top;
        headBars.Location = new Point(28, 20);
        headBars.Name = "headBars";
        headBars.Size = new Size(211, 42);
        headBars.TabIndex = 0;
        // 
        // lblTitleBars
        // 
        lblTitleBars.AutoSize = true;
        lblTitleBars.Dock = DockStyle.Left;
        lblTitleBars.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitleBars.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitleBars.Location = new Point(0, 0);
        lblTitleBars.Name = "lblTitleBars";
        lblTitleBars.Size = new Size(221, 36);
        lblTitleBars.TabIndex = 0;
        lblTitleBars.Text = "Thiết bị theo loại";
        lblTitleBars.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // cboBuilding
        // 
        cboBuilding.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        cboBuilding.DropDownStyle = ComboBoxStyle.DropDownList;
        cboBuilding.FlatStyle = FlatStyle.Flat;
        cboBuilding.Location = new Point(51, 6);
        cboBuilding.Name = "cboBuilding";
        cboBuilding.Size = new Size(160, 31);
        cboBuilding.TabIndex = 1;
        cboBuilding.SelectedIndexChanged += cboBuilding_SelectedIndexChanged;
        // 
        // cardList
        // 
        cardList.BackColor = Color.FromArgb(233, 238, 243);
        cardList.Controls.Add(bodyList);
        cardList.Controls.Add(gapList);
        cardList.Controls.Add(lineList);
        cardList.Controls.Add(headList);
        cardList.Dock = DockStyle.Fill;
        cardList.FillColor = Color.White;
        cardList.Location = new Point(622, 8);
        cardList.Margin = new Padding(8);
        cardList.Name = "cardList";
        cardList.Padding = new Padding(28, 20, 28, 18);
        cardList.Radius = 8;
        cardList.Size = new Size(346, 394);
        cardList.TabIndex = 4;
        // 
        // bodyList
        // 
        bodyList.BackColor = Color.White;
        bodyList.Controls.Add(pnlList);
        bodyList.Dock = DockStyle.Fill;
        bodyList.Location = new Point(28, 75);
        bodyList.Name = "bodyList";
        bodyList.Size = new Size(290, 301);
        bodyList.TabIndex = 3;
        // 
        // pnlList
        // 
        pnlList.Controls.Add(lblListEmpty);
        pnlList.Controls.Add(row5);
        pnlList.Controls.Add(row4);
        pnlList.Controls.Add(row3);
        pnlList.Controls.Add(row2);
        pnlList.Controls.Add(row1);
        pnlList.Controls.Add(rowHeader);
        pnlList.Dock = DockStyle.Fill;
        pnlList.Location = new Point(0, 0);
        pnlList.Name = "pnlList";
        pnlList.Size = new Size(290, 301);
        pnlList.TabIndex = 0;
        // 
        // lblListEmpty
        // 
        lblListEmpty.Dock = DockStyle.Top;
        lblListEmpty.ForeColor = Color.FromArgb(120, 130, 145);
        lblListEmpty.Location = new Point(0, 330);
        lblListEmpty.Name = "lblListEmpty";
        lblListEmpty.Size = new Size(290, 40);
        lblListEmpty.TabIndex = 6;
        lblListEmpty.Text = "Không có yêu cầu bảo trì nào đang chờ xử lý.";
        lblListEmpty.TextAlign = ContentAlignment.MiddleLeft;
        lblListEmpty.Visible = false;
        // 
        // row5
        // 
        row5.BackColor = Color.White;
        row5.Code = "";
        row5.Cursor = Cursors.Hand;
        row5.Dock = DockStyle.Top;
        row5.IsHeader = false;
        row5.Location = new Point(0, 272);
        row5.Name = "row5";
        row5.Size = new Size(290, 58);
        row5.Status = "";
        row5.TabIndex = 5;
        row5.Title = "";
        row5.Visible = false;
        row5.Click += this.row_Click;
        // 
        // row4
        // 
        row4.BackColor = Color.White;
        row4.Code = "";
        row4.Cursor = Cursors.Hand;
        row4.Dock = DockStyle.Top;
        row4.IsHeader = false;
        row4.Location = new Point(0, 214);
        row4.Name = "row4";
        row4.Size = new Size(290, 58);
        row4.Status = "";
        row4.TabIndex = 4;
        row4.Title = "";
        row4.Visible = false;
        row4.Click += this.row_Click;
        // 
        // row3
        // 
        row3.BackColor = Color.White;
        row3.Code = "";
        row3.Cursor = Cursors.Hand;
        row3.Dock = DockStyle.Top;
        row3.IsHeader = false;
        row3.Location = new Point(0, 156);
        row3.Name = "row3";
        row3.Size = new Size(290, 58);
        row3.Status = "";
        row3.TabIndex = 3;
        row3.Title = "";
        row3.Visible = false;
        row3.Click += this.row_Click;
        // 
        // row2
        // 
        row2.BackColor = Color.White;
        row2.Code = "";
        row2.Cursor = Cursors.Hand;
        row2.Dock = DockStyle.Top;
        row2.IsHeader = false;
        row2.Location = new Point(0, 98);
        row2.Name = "row2";
        row2.Size = new Size(290, 58);
        row2.Status = "";
        row2.TabIndex = 2;
        row2.Title = "";
        row2.Visible = false;
        row2.Click += this.row_Click;
        // 
        // row1
        // 
        row1.BackColor = Color.White;
        row1.Code = "";
        row1.Cursor = Cursors.Hand;
        row1.Dock = DockStyle.Top;
        row1.IsHeader = false;
        row1.Location = new Point(0, 40);
        row1.Name = "row1";
        row1.Size = new Size(290, 58);
        row1.Status = "";
        row1.TabIndex = 1;
        row1.Title = "";
        row1.Visible = false;
        row1.Click += this.row_Click;
        // 
        // rowHeader
        // 
        rowHeader.BackColor = Color.White;
        rowHeader.Code = "Thiết bị / sự cố";
        rowHeader.Dock = DockStyle.Top;
        rowHeader.IsHeader = true;
        rowHeader.Location = new Point(0, 0);
        rowHeader.Name = "rowHeader";
        rowHeader.Size = new Size(290, 40);
        rowHeader.Status = "Trạng thái";
        rowHeader.TabIndex = 0;
        rowHeader.Title = "";
        // 
        // gapList
        // 
        gapList.BackColor = Color.White;
        gapList.Dock = DockStyle.Top;
        gapList.Location = new Point(28, 63);
        gapList.Name = "gapList";
        gapList.Size = new Size(290, 12);
        gapList.TabIndex = 2;
        // 
        // lineList
        // 
        lineList.BackColor = Color.FromArgb(229, 233, 238);
        lineList.Dock = DockStyle.Top;
        lineList.Location = new Point(28, 62);
        lineList.Name = "lineList";
        lineList.Size = new Size(290, 1);
        lineList.TabIndex = 1;
        // 
        // headList
        // 
        headList.BackColor = Color.White;
        headList.Controls.Add(lblTitleList);
        headList.Dock = DockStyle.Top;
        headList.Location = new Point(28, 20);
        headList.Name = "headList";
        headList.Size = new Size(290, 42);
        headList.TabIndex = 0;
        // 
        // lblTitleList
        // 
        lblTitleList.AutoSize = true;
        lblTitleList.Dock = DockStyle.Left;
        lblTitleList.Font = new Font("Segoe UI", 15.5F, FontStyle.Bold);
        lblTitleList.ForeColor = Color.FromArgb(71, 85, 105);
        lblTitleList.Location = new Point(0, 0);
        lblTitleList.Name = "lblTitleList";
        lblTitleList.Size = new Size(299, 36);
        lblTitleList.TabIndex = 0;
        lblTitleList.Text = "Yêu cầu bảo trì gần đây";
        lblTitleList.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // DashboardControl
        // 
        AutoScaleDimensions = new SizeF(120F, 120F);
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Color.FromArgb(233, 238, 243);
        Controls.Add(pnlScroll);
        Font = new Font("Segoe UI", 10F);
        Name = "DashboardControl";
        Size = new Size(1025, 580);
        pnlScroll.ResumeLayout(false);
        tlRoot.ResumeLayout(false);
        tlRow1.ResumeLayout(false);
        cardInfo.ResumeLayout(false);
        bodyInfo.ResumeLayout(false);
        tlInfo.ResumeLayout(false);
        pnlAvatar.ResumeLayout(false);
        pnlAvatar.PerformLayout();
        headInfo.ResumeLayout(false);
        headInfo.PerformLayout();
        tlRight.ResumeLayout(false);
        cardRemind.ResumeLayout(false);
        tlRemind.ResumeLayout(false);
        pnlRemindLeft.ResumeLayout(false);
        pnlBell.ResumeLayout(false);
        tlTiles.ResumeLayout(false);
        tlShortcuts.ResumeLayout(false);
        tlRow3.ResumeLayout(false);
        cardDonut.ResumeLayout(false);
        bodyDonut.ResumeLayout(false);
        headDonut.ResumeLayout(false);
        headDonut.PerformLayout();
        cardBars.ResumeLayout(false);
        bodyBars.ResumeLayout(false);
        headBars.ResumeLayout(false);
        headBars.PerformLayout();
        cardList.ResumeLayout(false);
        bodyList.ResumeLayout(false);
        pnlList.ResumeLayout(false);
        headList.ResumeLayout(false);
        headList.PerformLayout();
        ResumeLayout(false);
    }

    private Panel pnlScroll;
    private TableLayoutPanel tlRoot;
    private TableLayoutPanel tlRow1;
    private TableLayoutPanel tlRight;
    private TableLayoutPanel tlTiles;
    private TableLayoutPanel tlShortcuts;
    private TableLayoutPanel tlRow3;
    private StatTile tileTotal;
    private StatTile tileAttention;
    private KeyValueList infoLeft;
    private KeyValueList infoRight;
    private DonutChart donut;
    private BarChart bars;
    private ComboBox cboBuilding;
    private Panel pnlList;
    private CardPanel cardInfo;
    private Panel headInfo;
    private Label lblTitleInfo;
    private Panel lineInfo;
    private Panel gapInfo;
    private Panel bodyInfo;
    private TableLayoutPanel tlInfo;
    private TableLayoutPanel pnlAvatar;
    private IconCircle circleInfo;
    private Label lnkInfoEdit;
    private Label lnkInfoMore;
    private CardPanel cardDonut;
    private Panel headDonut;
    private Label lblTitleDonut;
    private Panel lineDonut;
    private Panel gapDonut;
    private Panel bodyDonut;
    private CardPanel cardBars;
    private Panel headBars;
    private Label lblTitleBars;
    private Panel lineBars;
    private Panel gapBars;
    private Panel bodyBars;
    private CardPanel cardList;
    private Panel headList;
    private Label lblTitleList;
    private Panel lineList;
    private Panel gapList;
    private Panel bodyList;
    private CardPanel cardRemind;
    private Label lblRemindCaption;
    private TableLayoutPanel tlRemind;
    private Panel pnlRemindLeft;
    private Label lnkRemindMore;
    private Label lblRemindNumber;
    private Label lblRemindText;
    private Panel pnlBell;
    private IconCircle circleBell;
    private Label lblListEmpty;
    private ListRow rowHeader;
    private ListRow row1;
    private ListRow row2;
    private ListRow row3;
    private ListRow row4;
    private ListRow row5;
    private ShortcutTile tileBuildings;
    private ShortcutTile tileRooms;
    private ShortcutTile tileTypes;
    private ShortcutTile tileEquipment;
    private ShortcutTile tileMaintenance;
    private ShortcutTile tileReports;
    private ShortcutTile tileLast;
}
