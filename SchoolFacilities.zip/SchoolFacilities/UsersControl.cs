using System.Data;

namespace SchoolFacilities;

/// <summary>Quản lý người dùng (chỉ Admin). Mật khẩu được băm trước khi lưu.</summary>
public class UsersControl : CrudControl
{
    const string ListSqlText =
        @"SELECT UserId AS Id, Username AS [Tên đăng nhập], FullName AS [Họ tên], Role AS [Vai trò],
                 CASE WHEN IsActive = 1 THEN N'Đang hoạt động' ELSE N'Đã khóa' END AS [Trạng thái]
          FROM Users ORDER BY Username";

    static readonly List<FieldDef> FieldList = new()
    {
        new() { Column = "Username", Label = "Tên đăng nhập", Required = true },
        new() { Column = "FullName", Label = "Họ tên", Required = true },
        new() { Column = "Role", Label = "Vai trò", Kind = FieldKind.Combo, Required = true, ComboItems = new[] { "Admin", "Staff" } },
        new() { Column = "Password", Label = "Mật khẩu", Kind = FieldKind.Password },
        new() { Column = "IsActive", Label = "Đang hoạt động", Kind = FieldKind.Bool, Default = true },
    };

    public UsersControl()
        : base("Quản lý người dùng", "người dùng", "Users", "UserId", ListSqlText, FieldList, true)
    {
    }

    protected override string? ValidateValues(Dictionary<string, object?> v, bool isNew)
    {
        var pw = v["Password"] as string;
        if (isNew && string.IsNullOrEmpty(pw)) return "Vui lòng nhập mật khẩu cho người dùng mới.";
        if (!string.IsNullOrEmpty(pw) && pw.Length < 6) return "Mật khẩu phải có ít nhất 6 ký tự.";
        return null;
    }

    protected override Dictionary<string, object?> Transform(Dictionary<string, object?> v, bool isNew)
    {
        var copy = new Dictionary<string, object?>(v);
        var pw = copy["Password"] as string;
        copy.Remove("Password");
        if (!string.IsNullOrEmpty(pw)) copy["PasswordHash"] = Security.Hash(pw);
        return copy;
    }

    protected override string? CanDelete(int id) =>
        id == Session.UserId ? "Bạn không thể xóa chính tài khoản đang đăng nhập." : null;
}
