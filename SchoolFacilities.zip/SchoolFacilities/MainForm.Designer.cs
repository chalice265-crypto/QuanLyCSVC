#nullable disable
namespace SchoolFacilities;

partial class MainForm
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        pnlTop = new BufferedPanel();
        btnMenu = new IconButton();
        logo = new LogoControl();
        txtSearch = new PillTextBox();
        lnkHome = new NavLink();
        lnkBell = new NavLink();
        chipUser = new UserChip();
        pnlBody = new Panel();
        menuUser = new ContextMenuStrip(components);
        miChangePassword = new ToolStripMenuItem();
        miEditSchool = new ToolStripMenuItem();
        sepUser = new ToolStripSeparator();
        miLogout = new ToolStripMenuItem();
        menuModule = new ContextMenuStrip(components);
        miHome = new ToolStripMenuItem();
        sepModule = new ToolStripSeparator();
        miBuildings = new ToolStripMenuItem();
        miRooms = new ToolStripMenuItem();
        miTypes = new ToolStripMenuItem();
        miEquipment = new ToolStripMenuItem();
        miMaintenance = new ToolStripMenuItem();
        miReports = new ToolStripMenuItem();
        miUsers = new ToolStripMenuItem();
        menuUser.SuspendLayout();
        menuModule.SuspendLayout();
        pnlTop.SuspendLayout();
        SuspendLayout();
        // 
        // pnlTop
        // 
        pnlTop.BackColor = Color.White;
        pnlTop.Controls.Add(btnMenu);
        pnlTop.Controls.Add(logo);
        pnlTop.Controls.Add(txtSearch);
        pnlTop.Controls.Add(lnkHome);
        pnlTop.Controls.Add(lnkBell);
        pnlTop.Controls.Add(chipUser);
        pnlTop.Dock = DockStyle.Top;
        pnlTop.Location = new Point(0, 0);
        pnlTop.Name = "pnlTop";
        pnlTop.Size = new Size(1280, 66);
        pnlTop.TabIndex = 1;
        pnlTop.Paint += pnlTop_Paint;
        pnlTop.Resize += pnlTop_Resize;
        // 
        // btnMenu
        // 
        btnMenu.BackColor = Color.White;
        btnMenu.Kind = IconKind.Grid;
        btnMenu.Location = new Point(14, 13);
        btnMenu.Name = "btnMenu";
        btnMenu.Size = new Size(40, 40);
        btnMenu.TabIndex = 0;
        btnMenu.Click += btnMenu_Click;
        // 
        // logo
        // 
        logo.BackColor = Color.White;
        logo.Location = new Point(66, 9);
        logo.Name = "logo";
        logo.Size = new Size(330, 48);
        logo.TabIndex = 1;
        // 
        // txtSearch
        // 
        txtSearch.BackColor = Color.White;
        txtSearch.Location = new Point(420, 13);
        txtSearch.Name = "txtSearch";
        txtSearch.PlaceholderText = "Tìm chức năng hoặc thiết bị...";
        txtSearch.RightIcon = IconKind.Search;
        txtSearch.Size = new Size(440, 40);
        txtSearch.TabIndex = 2;
        txtSearch.EnterPressed += txtSearch_EnterPressed;
        // 
        // lnkHome
        // 
        lnkHome.BackColor = Color.White;
        lnkHome.Kind = IconKind.Home;
        lnkHome.Location = new Point(880, 11);
        lnkHome.Name = "lnkHome";
        lnkHome.Size = new Size(110, 44);
        lnkHome.TabIndex = 3;
        lnkHome.Click += lnkHome_Click;
        // 
        // lnkBell
        // 
        lnkBell.BackColor = Color.White;
        lnkBell.Kind = IconKind.Bell;
        lnkBell.Location = new Point(990, 11);
        lnkBell.Name = "lnkBell";
        lnkBell.Size = new Size(110, 44);
        lnkBell.TabIndex = 4;
        lnkBell.Click += lnkBell_Click;
        // 
        // chipUser
        // 
        chipUser.BackColor = Color.White;
        chipUser.Location = new Point(1100, 9);
        chipUser.Name = "chipUser";
        chipUser.Size = new Size(160, 48);
        chipUser.TabIndex = 5;
        chipUser.Click += chipUser_Click;
        // 
        // pnlBody
        // 
        pnlBody.BackColor = Color.FromArgb(233, 238, 243);
        pnlBody.Dock = DockStyle.Fill;
        pnlBody.Location = new Point(0, 66);
        pnlBody.Name = "pnlBody";
        pnlBody.Size = new Size(1280, 714);
        pnlBody.TabIndex = 0;
        // 
        // menuUser
        // 
        menuUser.Font = new Font("Segoe UI", 10.5F);
        menuUser.Items.AddRange(new ToolStripItem[] { miChangePassword, miEditSchool, sepUser, miLogout });
        menuUser.Name = "menuUser";
        menuUser.Size = new Size(260, 82);
        // 
        // miChangePassword
        // 
        miChangePassword.Name = "miChangePassword";
        miChangePassword.Text = "Đổi mật khẩu";
        miChangePassword.Click += miChangePassword_Click;
        // 
        // miEditSchool
        // 
        miEditSchool.Name = "miEditSchool";
        miEditSchool.Text = "Cập nhật thông tin trường";
        miEditSchool.Click += miEditSchool_Click;
        // 
        // sepUser
        // 
        sepUser.Name = "sepUser";
        sepUser.Size = new Size(256, 6);
        // 
        // miLogout
        // 
        miLogout.Name = "miLogout";
        miLogout.Text = "Đăng xuất";
        miLogout.Click += miLogout_Click;
        // 
        // menuModule
        // 
        menuModule.Font = new Font("Segoe UI", 10.5F);
        menuModule.Items.AddRange(new ToolStripItem[] { miHome, sepModule, miBuildings, miRooms, miTypes, miEquipment, miMaintenance, miReports, miUsers });
        menuModule.Name = "menuModule";
        menuModule.Size = new Size(200, 220);
        // 
        // miHome
        // 
        miHome.Name = "miHome";
        miHome.Text = "Trang chủ";
        miHome.Click += miHome_Click;
        // 
        // sepModule
        // 
        sepModule.Name = "sepModule";
        sepModule.Size = new Size(196, 6);
        // 
        // miBuildings
        // 
        miBuildings.Name = "miBuildings";
        miBuildings.Text = "Tòa nhà";
        miBuildings.Tag = "buildings";
        miBuildings.Click += miModule_Click;
        // 
        // miRooms
        // 
        miRooms.Name = "miRooms";
        miRooms.Text = "Phòng";
        miRooms.Tag = "rooms";
        miRooms.Click += miModule_Click;
        // 
        // miTypes
        // 
        miTypes.Name = "miTypes";
        miTypes.Text = "Loại thiết bị";
        miTypes.Tag = "types";
        miTypes.Click += miModule_Click;
        // 
        // miEquipment
        // 
        miEquipment.Name = "miEquipment";
        miEquipment.Text = "Thiết bị";
        miEquipment.Tag = "equipment";
        miEquipment.Click += miModule_Click;
        // 
        // miMaintenance
        // 
        miMaintenance.Name = "miMaintenance";
        miMaintenance.Text = "Bảo trì";
        miMaintenance.Tag = "maintenance";
        miMaintenance.Click += miModule_Click;
        // 
        // miReports
        // 
        miReports.Name = "miReports";
        miReports.Text = "Báo cáo";
        miReports.Tag = "reports";
        miReports.Click += miModule_Click;
        // 
        // miUsers
        // 
        miUsers.Name = "miUsers";
        miUsers.Text = "Người dùng";
        miUsers.Tag = "users";
        miUsers.Click += miModule_Click;
        // 
        // MainForm
        // 
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = Color.FromArgb(233, 238, 243);
        ClientSize = new Size(1280, 780);
        Controls.Add(pnlBody);
        Controls.Add(pnlTop);
        Font = new Font("Segoe UI", 10F);
        MinimumSize = new Size(1100, 680);
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Quản lý cơ sở vật chất";
        pnlTop.ResumeLayout(false);
        menuUser.ResumeLayout(false);
        menuModule.ResumeLayout(false);
        ResumeLayout(false);
    }

    private BufferedPanel pnlTop;
    private Panel pnlBody;
    private IconButton btnMenu;
    private LogoControl logo;
    private PillTextBox txtSearch;
    private NavLink lnkHome;
    private NavLink lnkBell;
    private UserChip chipUser;
    private ContextMenuStrip menuUser;
    private ContextMenuStrip menuModule;
    private ToolStripMenuItem miChangePassword;
    private ToolStripMenuItem miEditSchool;
    private ToolStripSeparator sepUser;
    private ToolStripMenuItem miLogout;
    private ToolStripMenuItem miHome;
    private ToolStripSeparator sepModule;
    private ToolStripMenuItem miBuildings;
    private ToolStripMenuItem miRooms;
    private ToolStripMenuItem miTypes;
    private ToolStripMenuItem miEquipment;
    private ToolStripMenuItem miMaintenance;
    private ToolStripMenuItem miReports;
    private ToolStripMenuItem miUsers;
}
