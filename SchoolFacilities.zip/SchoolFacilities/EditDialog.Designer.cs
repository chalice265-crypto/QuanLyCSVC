#nullable disable
namespace SchoolFacilities;

partial class EditDialog
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        root = new FlowLayoutPanel();
        lblHeading = new Label();
        tlFields = new TableLayoutPanel();
        pnlButtons = new Panel();
        btnOk = new Button();
        btnCancel = new Button();
        root.SuspendLayout();
        pnlButtons.SuspendLayout();
        SuspendLayout();
        // 
        // root
        // 
        root.AutoSize = true;
        root.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        root.BackColor = Color.White;
        root.Controls.Add(lblHeading);
        root.Controls.Add(tlFields);
        root.Controls.Add(pnlButtons);
        root.FlowDirection = FlowDirection.TopDown;
        root.Location = new Point(0, 0);
        root.Margin = new Padding(0);
        root.Name = "root";
        root.Size = new Size(500, 180);
        root.TabIndex = 0;
        root.WrapContents = false;
        // 
        // lblHeading
        // 
        lblHeading.BackColor = Color.White;
        lblHeading.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblHeading.ForeColor = Color.FromArgb(71, 85, 105);
        lblHeading.Location = new Point(0, 0);
        lblHeading.Margin = new Padding(0);
        lblHeading.Name = "lblHeading";
        lblHeading.Padding = new Padding(18, 10, 0, 0);
        lblHeading.Size = new Size(500, 52);
        lblHeading.TabIndex = 0;
        lblHeading.Text = "Tiêu đề";
        lblHeading.TextAlign = ContentAlignment.MiddleLeft;
        // 
        // tlFields
        // 
        tlFields.AutoSize = true;
        tlFields.BackColor = Color.White;
        tlFields.ColumnCount = 2;
        tlFields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150F));
        tlFields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 310F));
        tlFields.Location = new Point(0, 52);
        tlFields.Margin = new Padding(0);
        tlFields.Name = "tlFields";
        tlFields.Padding = new Padding(18, 4, 18, 4);
        tlFields.Size = new Size(500, 8);
        tlFields.TabIndex = 1;
        // 
        // pnlButtons
        // 
        pnlButtons.BackColor = Color.White;
        pnlButtons.Controls.Add(btnOk);
        pnlButtons.Controls.Add(btnCancel);
        pnlButtons.Location = new Point(0, 60);
        pnlButtons.Margin = new Padding(0);
        pnlButtons.Name = "pnlButtons";
        pnlButtons.Size = new Size(500, 64);
        pnlButtons.TabIndex = 2;
        // 
        // btnOk
        // 
        btnOk.BackColor = Color.FromArgb(24, 160, 245);
        btnOk.Cursor = Cursors.Hand;
        btnOk.FlatAppearance.BorderSize = 0;
        btnOk.FlatAppearance.MouseOverBackColor = Color.FromArgb(58, 174, 247);
        btnOk.FlatStyle = FlatStyle.Flat;
        btnOk.ForeColor = Color.White;
        btnOk.Location = new Point(274, 12);
        btnOk.Name = "btnOk";
        btnOk.Size = new Size(104, 38);
        btnOk.TabIndex = 0;
        btnOk.Text = "Lưu";
        btnOk.UseVisualStyleBackColor = false;
        btnOk.Click += btnOk_Click;
        // 
        // btnCancel
        // 
        btnCancel.BackColor = Color.FromArgb(100, 116, 139);
        btnCancel.Cursor = Cursors.Hand;
        btnCancel.DialogResult = DialogResult.Cancel;
        btnCancel.FlatAppearance.BorderSize = 0;
        btnCancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(123, 137, 157);
        btnCancel.FlatStyle = FlatStyle.Flat;
        btnCancel.ForeColor = Color.White;
        btnCancel.Location = new Point(386, 12);
        btnCancel.Name = "btnCancel";
        btnCancel.Size = new Size(96, 38);
        btnCancel.TabIndex = 1;
        btnCancel.Text = "Hủy";
        btnCancel.UseVisualStyleBackColor = false;
        // 
        // EditDialog
        // 
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        BackColor = Color.White;
        CancelButton = btnCancel;
        ClientSize = new Size(500, 180);
        Controls.Add(root);
        Font = new Font("Segoe UI", 10F);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "EditDialog";
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        Text = "Hộp thoại";
        root.ResumeLayout(false);
        root.PerformLayout();
        pnlButtons.ResumeLayout(false);
        ResumeLayout(false);
        PerformLayout();
    }

    private FlowLayoutPanel root;
    private Label lblHeading;
    private TableLayoutPanel tlFields;
    private Panel pnlButtons;
    private Button btnOk;
    private Button btnCancel;
}
