using System.Data;

namespace SchoolFacilities;

/// <summary>Quản lý thiết bị: thêm/sửa/xóa + điều chuyển phòng + báo hỏng.</summary>
public class EquipmentControl : CrudControl
{
    const string ListSqlText =
        @"SELECT e.EquipmentId AS Id, e.AssetCode AS [Mã tài sản], e.Name AS [Tên thiết bị], t.Name AS [Loại],
                 ISNULL(r.Code + N' - ' + r.Name, N'(Chưa gán phòng)') AS [Phòng],
                 e.PurchaseDate AS [Ngày mua], e.Price AS [Giá trị], e.Status AS [Tình trạng]
          FROM Equipment e
          JOIN EquipmentTypes t ON t.TypeId = e.TypeId
          LEFT JOIN Rooms r ON r.RoomId = e.RoomId
          ORDER BY e.AssetCode";

    static readonly List<FieldDef> FieldList = new()
    {
        new() { Column = "AssetCode", Label = "Mã tài sản", Required = true },
        new() { Column = "Name", Label = "Tên thiết bị", Required = true },
        new() { Column = "TypeId", Label = "Loại thiết bị", Kind = FieldKind.Combo, Required = true, ComboSql = Sql.TypeCombo },
        new() { Column = "RoomId", Label = "Phòng đang đặt", Kind = FieldKind.Combo, AllowNull = true, ComboSql = Sql.RoomCombo },
        new() { Column = "PurchaseDate", Label = "Ngày mua", Kind = FieldKind.Date, AllowNull = true },
        new() { Column = "Price", Label = "Giá trị (đ)", Kind = FieldKind.Decimal },
        new() { Column = "Status", Label = "Tình trạng", Kind = FieldKind.Combo, Required = true, ComboItems = Lists.EquipmentStatus },
        new() { Column = "Note", Label = "Ghi chú", Kind = FieldKind.Multiline },
    };

    public EquipmentControl()
        : base("Quản lý thiết bị / tài sản", "thiết bị", "Equipment", "EquipmentId", ListSqlText, FieldList, Session.IsAdmin)
    {
        // Hai nút này dựng sẵn trong CrudControl.Designer (btnTransfer, btnBroken): ở đây chỉ bật lên.
        BtnTransfer.Visible = true;
        BtnTransfer.Click += (_, _) => Transfer();
        BtnBroken.Visible = true;
        BtnBroken.Click += (_, _) => ReportBroken();
    }

    // Ghi lịch sử điều chuyển khi đổi phòng bằng hộp thoại Sửa.
    protected override void AfterSave(int? id, DataRow? oldRow, Dictionary<string, object?> v, bool isNew)
    {
        if (isNew || id == null || oldRow == null) return;
        object? oldRoom = oldRow["RoomId"] is DBNull ? null : oldRow["RoomId"];
        v.TryGetValue("RoomId", out var newRoom);
        if (object.Equals(oldRoom, newRoom)) return;

        Db.Exec(@"INSERT INTO EquipmentTransfers (EquipmentId, FromRoomId, ToRoomId, ByUser, Note)
                  VALUES (@e, @f, @t, @u, N'Cập nhật từ biểu mẫu sửa thiết bị')",
                ("@e", id.Value), ("@f", oldRoom), ("@t", newRoom), ("@u", Session.UserId));
    }

    void Transfer()
    {
        var id = RequireSelection();
        if (id == null) return;

        var fields = new List<FieldDef>
        {
            new() { Column = "ToRoomId", Label = "Chuyển đến phòng", Kind = FieldKind.Combo, Required = true, ComboSql = Sql.RoomCombo },
            new() { Column = "Note", Label = "Ghi chú", Kind = FieldKind.Multiline },
        };
        using var dlg = new EditDialog("Điều chuyển thiết bị", fields);
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;

        try
        {
            Db.Exec(@"SET XACT_ABORT ON; BEGIN TRAN;
                      INSERT INTO EquipmentTransfers (EquipmentId, FromRoomId, ToRoomId, ByUser, Note)
                      SELECT EquipmentId, RoomId, @to, @uid, @note FROM Equipment WHERE EquipmentId = @id;
                      UPDATE Equipment SET RoomId = @to WHERE EquipmentId = @id;
                      COMMIT;",
                    ("@id", id.Value), ("@to", dlg.Values["ToRoomId"]), ("@uid", Session.UserId), ("@note", dlg.Values["Note"]));
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }

    void ReportBroken()
    {
        var id = RequireSelection();
        if (id == null) return;

        var fields = new List<FieldDef>
        {
            new() { Column = "Description", Label = "Mô tả sự cố", Kind = FieldKind.Multiline, Required = true },
        };
        using var dlg = new EditDialog("Báo hỏng thiết bị", fields);
        if (dlg.ShowDialog(FindForm()) != DialogResult.OK) return;

        try
        {
            Db.Exec(@"SET XACT_ABORT ON; BEGIN TRAN;
                      INSERT INTO Maintenance (EquipmentId, ReportDate, Description, Status, ReportedBy)
                      VALUES (@id, CAST(GETDATE() AS DATE), @d, N'Chờ xử lý', @uid);
                      UPDATE Equipment SET Status = N'Hỏng' WHERE EquipmentId = @id;
                      COMMIT;",
                    ("@id", id.Value), ("@d", dlg.Values["Description"]), ("@uid", Session.UserId));
            LoadData();
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
    }
}
